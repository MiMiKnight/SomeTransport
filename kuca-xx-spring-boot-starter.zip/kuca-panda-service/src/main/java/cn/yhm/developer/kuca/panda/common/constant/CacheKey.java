package cn.yhm.developer.kuca.panda.common.constant;

/**
 * 缓存键的常量
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-12 10:42:56
 */
public interface CacheKey {

    /**
     * 分隔符
     */
    String SEPARATOR = ":";

    /**
     * 项目顶级缓存前缀
     */
    String TOP_CACHE_PREFIX = ProjectConstant.App.NAME + SEPARATOR;

    /**
     * 公共模块
     */
    interface Common {
        /**
         * 当前模块缓存前缀
         */
        String MODULE_CACHE_PREFIX = TOP_CACHE_PREFIX + "Common" + SEPARATOR;
    }

    /**
     * Content模块
     */
    interface Content {

        /**
         * 当前模块缓存前缀
         */
        String MODULE_CACHE_PREFIX = TOP_CACHE_PREFIX + "Content" + SEPARATOR;

        /**
         * 更新锁
         */
        String UPDATE_CONTENT_LOCK = MODULE_CACHE_PREFIX + "Lock-Update-Content";

    }

}
