package cn.yhm.developer.kuca.panda.rest.handler.content;

import cn.yhm.developer.kuca.ecology.core.EcologyHandleable;
import cn.yhm.developer.kuca.panda.model.request.GetContentByIdRequest;
import cn.yhm.developer.kuca.panda.model.response.GetContentByIdResponse;
import org.springframework.stereotype.Component;

/**
 * 审核内容处理器类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-09 20:32:18
 */
@Component
public class GetContentByIdHandler implements EcologyHandleable<GetContentByIdRequest, GetContentByIdResponse> {
    @Override
    public void handle(GetContentByIdRequest request, GetContentByIdResponse auditContentResponse) throws Exception {
        Long id = request.getId();
    }
}
