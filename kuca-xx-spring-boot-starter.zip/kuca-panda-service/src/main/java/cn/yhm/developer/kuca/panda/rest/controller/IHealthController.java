package cn.yhm.developer.kuca.panda.rest.controller;

import cn.yhm.developer.kuca.ecology.model.response.ResultResponse;
import cn.yhm.developer.kuca.panda.model.response.HealthCheckResponse;

/**
 * 健康检查前端控制器接口
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-09 20:21:04
 */
public interface IHealthController {

    /**
     * 健康检查接口
     *
     * @return {@link HealthCheckResponse}
     * @throws Exception 异常
     */
    ResultResponse<HealthCheckResponse> v1() throws Exception;
}
