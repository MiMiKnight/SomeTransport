package cn.yhm.developer.kuca.panda.model.request;

import cn.yhm.developer.kuca.ecology.model.request.EcologyRequest;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * @author victor2015yhm@gmail.com
 * @since 2023-03-09 20:26:22
 */
@Getter
@Setter
public class GetContentByIdRequest implements EcologyRequest {

    /**
     * 主键
     */
    @JsonProperty(value = "id", index = 1)
    private Long id;

}
