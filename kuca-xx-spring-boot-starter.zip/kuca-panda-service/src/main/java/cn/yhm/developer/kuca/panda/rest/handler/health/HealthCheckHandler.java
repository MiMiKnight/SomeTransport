package cn.yhm.developer.kuca.panda.rest.handler.health;

import cn.yhm.developer.kuca.ecology.core.EcologyHandleable;
import cn.yhm.developer.kuca.panda.common.enumeration.ErrorReturn;
import cn.yhm.developer.kuca.panda.common.util.ParamValidUtils;
import cn.yhm.developer.kuca.panda.model.request.HealthCheckRequest;
import cn.yhm.developer.kuca.panda.model.response.HealthCheckResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.function.BiPredicate;

/**
 * 健康检查处理器类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-09 00:14:27
 */
@Slf4j
@Component
public class HealthCheckHandler implements EcologyHandleable<HealthCheckRequest, HealthCheckResponse> {

    @Value("${spring.application.name}")
    private String serviceName;

    @Override
    public void handle(HealthCheckRequest request, HealthCheckResponse response) throws Exception {
        response.setServiceName(serviceName);
        response.setRunStatus("up");
        int age = 16;
        ParamValidUtils.valid(age, 18, ErrorReturn.SERVICE_ERROR_001, validAge);
        boolean legal = ParamValidUtils.isLegal(age, 18, validAge);
    }

    /**
     * 校验年龄
     */
    private final BiPredicate<Integer, Integer> validAge = (age, integer) -> age >= integer;
}
