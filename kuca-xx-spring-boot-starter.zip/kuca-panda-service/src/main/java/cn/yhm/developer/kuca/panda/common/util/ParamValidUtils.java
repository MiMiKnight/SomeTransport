package cn.yhm.developer.kuca.panda.common.util;

import cn.yhm.developer.kuca.panda.common.enumeration.ErrorReturn;

import java.util.function.BiPredicate;
import java.util.function.Predicate;

/**
 * 手动校验参数工具类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-11 00:40:51
 */
public class ParamValidUtils {

    /**
     * 判断参数是否合法
     * <p>
     * 校验逻辑返回false则表示不合法
     * <p>
     * 校验逻辑返回true则表示合法
     *
     * @param value     待校验的值
     * @param predicate 断言函数式接口,实际校验逻辑
     * @return boolean 是否校验通过,true：是，false：否
     * @throws Exception 异常
     */
    public static <T> boolean isLegal(T value, Predicate<T> predicate) throws Exception {
        return predicate.test(value);
    }

    /**
     * 判断参数是否合法
     * <p>
     * 校验逻辑返回false则表示不合法
     * <p>
     * 校验逻辑返回true则表示合法
     *
     * @param value     待被验证的数据
     * @param input     被输入的数据
     * @param predicate 断言函数式接口,实际校验逻辑
     * @return boolean
     * @throws Exception 异常
     */
    public static <T, U> boolean isLegal(T value, U input, BiPredicate<T, U> predicate) throws Exception {
        return predicate.test(value, input);
    }

    /**
     * 校验方法
     *
     * @param value       待校验的值
     * @param errorReturn 校验未通过时抛出异常的错误信息对象
     * @param predicate   断言函数式接口,实际校验逻辑
     * @throws Exception 异常
     */
    public static <T> void valid(T value, ErrorReturn errorReturn, Predicate<T> predicate) throws Exception {
        if (isLegal(value, predicate)) {
            return;
        }
        // 参数校验未通过则抛出异常
        ThrowExceptionUtils.doIt(errorReturn);
    }

    /**
     * 校验方法
     *
     * @param value       待被验证的数据
     * @param input       被输入的数据
     * @param errorReturn 校验未通过时抛出异常的错误信息对象
     * @param predicate   断言函数式接口,实际校验逻辑
     * @throws Exception 异常
     */
    public static <T, U> void valid(T value, U input, ErrorReturn errorReturn, BiPredicate<T, U> predicate) throws Exception {
        if (isLegal(value, input, predicate)) {
            return;
        }
        // 参数校验未通过则抛出异常
        ThrowExceptionUtils.doIt(errorReturn);
    }

    /**
     * 校验方法
     *
     * @param value       待校验的值
     * @param errorReturn 校验未通过时抛出异常的错误信息对象
     * @param predicate   断言函数式接口,实际校验逻辑
     * @param msg         日志，当校验失败抛出异常前打印该日志
     * @throws Exception 异常
     */
    public static <T> void valid(T value, ErrorReturn errorReturn, Predicate<T> predicate, String msg) throws Exception {
        if (isLegal(value, predicate)) {
            return;
        }
        // 参数校验未通过则抛出异常
        ThrowExceptionUtils.doIt(errorReturn, msg);
    }

    /**
     * 校验方法
     *
     * @param value       待被验证的数据
     * @param input       被输入的数据
     * @param errorReturn 校验未通过时抛出异常的错误信息对象
     * @param predicate   断言函数式接口,实际校验逻辑
     * @param msg         日志，当校验失败抛出异常前打印该日志
     * @throws Exception 异常
     */
    public static <T, U> void valid(T value, U input, ErrorReturn errorReturn, BiPredicate<T, U> predicate, String msg) throws Exception {
        if (isLegal(value, input, predicate)) {
            return;
        }
        // 参数校验未通过则抛出异常
        ThrowExceptionUtils.doIt(errorReturn, msg);
    }

    /**
     * 校验方法
     *
     * @param value       待校验的值
     * @param errorReturn 校验未通过时抛出异常的错误信息对象
     * @param predicate   断言函数式接口,实际校验逻辑
     * @param msg         日志，当校验失败抛出异常前打印该日志
     * @param args        日志参数
     * @throws Exception 异常
     */
    public static <T> void valid(T value, ErrorReturn errorReturn, Predicate<T> predicate, String msg,
                                 Object... args) throws Exception {
        if (isLegal(value, predicate)) {
            return;
        }
        // 参数校验未通过则抛出异常
        ThrowExceptionUtils.doIt(errorReturn, msg, args);
    }

    /**
     * 校验方法
     *
     * @param value       待被验证的数据
     * @param input       被输入的数据
     * @param errorReturn 校验未通过时抛出异常的错误信息对象
     * @param predicate   断言函数式接口,实际校验逻辑
     * @param msg         日志，当校验失败抛出异常前打印该日志
     * @param args        日志参数
     * @throws Exception 异常
     */
    public static <T, U> void valid(T value, U input, ErrorReturn errorReturn, BiPredicate<T, U> predicate,
                                    String msg, Object... args) throws Exception {
        if (isLegal(value, input, predicate)) {
            return;
        }
        // 参数校验未通过则抛出异常
        ThrowExceptionUtils.doIt(errorReturn, msg, args);
    }

}
