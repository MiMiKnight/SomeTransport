package cn.yhm.developer.kuca.panda.rest.handler.content;

import cn.yhm.developer.kuca.ecology.core.EcologyHandleable;
import cn.yhm.developer.kuca.panda.model.request.AuditContentRequest;
import cn.yhm.developer.kuca.panda.model.response.AuditContentResponse;
import org.springframework.stereotype.Component;

/**
 * 审核内容处理器类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-09 20:32:18
 */
@Component
public class AuditContentHandler implements EcologyHandleable<AuditContentRequest, AuditContentResponse> {

    @Override
    public void handle(AuditContentRequest request, AuditContentResponse response) throws Exception {
        Integer auditResult = request.getAuditResult();
        String auditTime = request.getAuditTime();
    }
}
