package cn.yhm.developer.kuca.panda.rest.controller;

import cn.yhm.developer.kuca.ecology.model.response.ResultResponse;
import cn.yhm.developer.kuca.panda.model.request.AuditContentRequest;
import cn.yhm.developer.kuca.panda.model.response.AuditContentResponse;
import cn.yhm.developer.kuca.panda.model.response.GetContentByIdResponse;

/**
 * 内容前端控制器接口
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-09 20:23:33
 */
public interface IContentController {

    /**
     * 内容审核接口
     *
     * @param request 请求参数
     * @return {@link ResultResponse}<{@link AuditContentResponse}>
     * @throws Exception 异常
     */
    ResultResponse<AuditContentResponse> v1(AuditContentRequest request) throws Exception;

    /**
     * 根据主键获取Content信息
     *
     * @param id 主键
     * @return {@link ResultResponse}<{@link GetContentByIdResponse}>
     * @throws Exception 异常
     */
    ResultResponse<GetContentByIdResponse> v1(Long id) throws Exception;
}
