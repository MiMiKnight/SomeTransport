package cn.yhm.developer.kuca.panda.common.util;

import cn.yhm.developer.kuca.panda.common.enumeration.ErrorReturn;
import cn.yhm.developer.kuca.panda.common.exception.ServiceException;
import lombok.extern.slf4j.Slf4j;

/**
 * 手动抛出自定义异常的工具类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-11 00:49:38
 */
@Slf4j
public class ThrowExceptionUtils {

    /**
     * 手动抛出自定义异常
     *
     * @param errorReturn 错误信息对象
     * @throws Exception 异常
     */
    public static void doIt(ErrorReturn errorReturn) throws Exception {
        throw new ServiceException(errorReturn);
    }

    /**
     * 手动抛出自定义异常
     *
     * @param errorReturn 错误信息对象
     * @param msg         日志
     * @throws Exception 异常
     */
    public static void doIt(ErrorReturn errorReturn, String msg) throws Exception {
        log.warn(msg);
        doIt(errorReturn);
    }

    /**
     * 手动抛出自定义异常
     *
     * @param errorReturn 错误信息对象
     * @param msg         日志
     * @param arguments   日志参数
     * @throws Exception 异常
     */
    public static void doIt(ErrorReturn errorReturn, String msg, Object... arguments) throws Exception {
        log.warn(msg, arguments);
        doIt(errorReturn);
    }


    /**
     * 手动抛出自定义异常
     *
     * @param isThrow     是否抛出
     * @param errorReturn 错误信息对象
     * @throws Exception 异常
     */
    public static void doIt(boolean isThrow, ErrorReturn errorReturn) throws Exception {
        if (isThrow) {
            doIt(errorReturn);
        }
    }

}
