package cn.yhm.developer.kuca.panda.rest.controller.impl;

import cn.yhm.developer.kuca.ecology.core.AbstractEcologyHandlerAdapter;
import cn.yhm.developer.kuca.ecology.model.response.ResultResponse;
import cn.yhm.developer.kuca.panda.common.constant.ApiPath;
import cn.yhm.developer.kuca.panda.model.request.AuditContentRequest;
import cn.yhm.developer.kuca.panda.model.request.GetContentByIdRequest;
import cn.yhm.developer.kuca.panda.model.response.AuditContentResponse;
import cn.yhm.developer.kuca.panda.model.response.GetContentByIdResponse;
import cn.yhm.developer.kuca.panda.rest.controller.IContentController;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * 内容前端控制器
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-09 20:24:11
 */
@RestController
@RequestMapping(path = ApiPath.Module.CONTENT, produces = {MediaType.APPLICATION_JSON_VALUE})
public class ContentController extends AbstractEcologyHandlerAdapter implements IContentController {

    @PostMapping(value = "/v1/audit")
    @Override
    public ResultResponse<AuditContentResponse> v1(@RequestBody @Validated AuditContentRequest request) throws Exception {
        return handle(request);
    }

    @GetMapping(value = "/v1/get-content-by-id")
    @Override
    public ResultResponse<GetContentByIdResponse> v1(@RequestParam("id") Long id) throws Exception {
        GetContentByIdRequest request = new GetContentByIdRequest();
        request.setId(id);
        return handle(request);
    }


}
