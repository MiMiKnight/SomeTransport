package cn.yhm.developer.kuca.panda.rest.controller.impl;

import cn.yhm.developer.kuca.ecology.core.AbstractEcologyHandlerAdapter;
import cn.yhm.developer.kuca.ecology.model.response.ResultResponse;
import cn.yhm.developer.kuca.panda.common.constant.ApiPath;
import cn.yhm.developer.kuca.panda.model.request.HealthCheckRequest;
import cn.yhm.developer.kuca.panda.model.response.HealthCheckResponse;
import cn.yhm.developer.kuca.panda.rest.controller.IHealthController;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 健康检查前端控制器
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-09 00:09:37
 */
@RestController
@RequestMapping(path = ApiPath.Module.HEALTH, produces = {MediaType.APPLICATION_JSON_VALUE})
public class HealthController extends AbstractEcologyHandlerAdapter implements IHealthController {

    @GetMapping(path = "/v1/check")
    @Override
    public ResultResponse<HealthCheckResponse> v1() throws Exception {
        return handle(new HealthCheckRequest());
    }
}
