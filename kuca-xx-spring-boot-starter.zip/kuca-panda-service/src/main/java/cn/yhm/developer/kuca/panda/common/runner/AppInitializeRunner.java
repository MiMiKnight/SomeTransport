package cn.yhm.developer.kuca.panda.common.runner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * 项目初始化类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-09 00:17:17
 */
@Order(value = 1)
@Component
public class AppInitializeRunner implements CommandLineRunner {

    private AppInitializeContainer initializeContainer;

    @Autowired
    public void setInitializeContainer(AppInitializeContainer initializeContainer) {
        this.initializeContainer = initializeContainer;
    }

    @Override
    public void run(String... args) throws Exception {
        initializeContainer.init();
    }
}
