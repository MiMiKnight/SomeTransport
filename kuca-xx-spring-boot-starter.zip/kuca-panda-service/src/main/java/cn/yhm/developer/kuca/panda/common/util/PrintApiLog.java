package cn.yhm.developer.kuca.panda.common.util;

import cn.yhm.developer.kuca.panda.common.constant.ProjectConstant;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Parameter;

/**
 * @author victor2015yhm@gmail.com
 * @since 2023-03-12 21:55:11
 */
@Slf4j
public class PrintApiLog {

    public static void printRequestApiLog(String uri, String requestMethod, Parameter[] parameters, Object[] args) {
        log.info(ProjectConstant.Log.API_LOG_REQUEST_FORMAT, requestMethod, uri, "request-params");
    }

    public static void printResponseApiLog(long cost, int status, String uri, String requestMethod, Parameter[] parameters,
                                           Object[] args) {
        log.info(ProjectConstant.Log.API_LOG_RESPONSE_FORMAT, cost, status, requestMethod, uri,
                "response-params");
    }
}
