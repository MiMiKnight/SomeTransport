package cn.yhm.developer.kuca.panda.model.request;

import cn.yhm.developer.kuca.ecology.model.request.EcologyRequest;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * @author victor2015yhm@gmail.com
 * @since 2023-03-09 20:26:22
 */
@Getter
@Setter
public class AuditContentRequest implements EcologyRequest {

    /**
     * 审核结果
     */
    @JsonProperty(value = "audit_result", index = 1)
    private Integer auditResult;

    /**
     * 审核时间
     */
    @JsonProperty(value = "audit_time", index = 2)
    private String auditTime;
}
