package cn.yhm.developer.kuca.panda.model.response;

import cn.yhm.developer.kuca.ecology.model.response.EcologyResponse;
import lombok.Getter;
import lombok.Setter;

/**
 * 内容审核响应
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-09 20:26:22
 */
@Getter
@Setter
public class AuditContentResponse implements EcologyResponse {
}
