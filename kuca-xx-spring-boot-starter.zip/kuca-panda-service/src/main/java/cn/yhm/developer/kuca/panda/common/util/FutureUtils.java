package cn.yhm.developer.kuca.panda.common.util;

/**
 * 多线程处理工具类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-12 22:36:10
 */
public class FutureUtils {
}
