package cn.yhm.developer.kuca.panda.common.runner;

import cn.yhm.developer.kuca.ecology.model.tip.ErrorFieldTip;
import cn.yhm.developer.kuca.ecology.model.tip.ErrorTip;
import cn.yhm.developer.kuca.panda.common.enumeration.ErrorReturn;
import cn.yhm.developer.kuca.panda.common.enumeration.ErrorType;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 项目初始化容器
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-10 19:00:24
 */
@Slf4j
@Getter
@Component
public class AppInitializeContainer {

    /**
     * 异常信息对象Map
     */
    private Map<String, ErrorReturn> errorReturnMap;

    /**
     * 异常类型Map
     */
    private Map<Integer, ErrorType> errorTypeMap;


    private interface ExceptionMessage {
        String MESSAGE_001 = "The \"error code\" of enumeration [{}] is duplicate definition,error code = {}";
        String MESSAGE_002 = "The \"error code\" of enumeration [%s] is duplicate definition.";
        String MESSAGE_003 = "The \"http code\" of enumeration [{}] is duplicate definition,http code = {}";
        String MESSAGE_004 = "The \"http code\" of enumeration [%s] is duplicate definition.";
        String MESSAGE_005 = "The enumeration [{}] \"tip\" field data type is illegal, error code = {}";
        String MESSAGE_006 = "The enumeration [%s] \"tip\" field data type is illegal.";

    }

    public void init() {
        this.initErrorReturnMap();
        this.initErrorTypeMap();
        this.checkErrorReturnTipDataType();
    }

    /**
     * 初始化ErrorReturnMap
     */
    private void initErrorReturnMap() {
        ErrorReturn[] errorReturns = ErrorReturn.values();
        if (errorReturns.length < 1) {
            return;
        }
        this.errorReturnMap = Arrays.stream(errorReturns).parallel()
                .collect(Collectors.toMap(ErrorReturn::getErrorCode,
                        item -> item,
                        (e1, e2) -> {
                            String name = ErrorReturn.class.getName();
                            // 检测出重复的 error code 则抛出异常
                            log.error(ExceptionMessage.MESSAGE_001, name, e1.getErrorCode());
                            throw new RuntimeException(String.format(ExceptionMessage.MESSAGE_002, name));
                        }));
    }

    /**
     * 校验ErrorType类的HTTP状态码是否重复定义
     */
    private void initErrorTypeMap() {
        ErrorType[] errorTypes = ErrorType.values();
        if (errorTypes.length < 1) {
            return;
        }
        this.errorTypeMap = Arrays.stream(errorTypes).parallel()
                .collect(Collectors.toMap(ErrorType::getHttpStatusCode,
                        item -> item,
                        (e1, e2) -> {
                            String name = ErrorType.class.getName();
                            // 检测出重复的 HTTP状态码 则抛出异常
                            log.error(ExceptionMessage.MESSAGE_003, name, e1.getHttpStatusCode());
                            throw new RuntimeException(String.format(ExceptionMessage.MESSAGE_004, name));
                        }));
    }

    /**
     * 检测{@link ErrorReturn ErrorReturn}对象的tip字段数据类型是否合法
     * <p>
     * 仅限传入以下类型参数，项目启动时会扫描检测，检测不符合要求则项目启动失败并报错给出提示信息
     * <p>
     * 错误提示类：{@link ErrorTip}
     * <p>
     * 错误字段提示类：{@link ErrorFieldTip}
     * <p>
     * 字符串：{@link String}
     * <p>
     * 哈希Map：{@link java.util.HashMap}
     */
    private void checkErrorReturnTipDataType() {
        ErrorReturn[] errorReturns = ErrorReturn.values();
        if (errorReturns.length < 1) {
            return;
        }
        Arrays.stream(errorReturns).parallel().forEach(item -> {
            Object tip = item.getTip();
            // 检测出不合法的tip字段数据类型则抛出异常
            boolean isIllegal = !((tip instanceof String) || (tip instanceof ErrorTip) || (tip instanceof HashMap));
            // 如果非法
            if (isIllegal) {
                String name = ErrorType.class.getName();
                log.error(ExceptionMessage.MESSAGE_005, name, item.getErrorCode());
                throw new RuntimeException(String.format(ExceptionMessage.MESSAGE_006, name));
            }
        });
    }
}
