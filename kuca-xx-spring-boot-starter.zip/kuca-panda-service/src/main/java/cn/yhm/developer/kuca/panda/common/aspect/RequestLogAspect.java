package cn.yhm.developer.kuca.panda.common.aspect;


import cn.yhm.developer.kuca.panda.common.constant.AspectRule;
import cn.yhm.developer.kuca.panda.common.util.PrintApiLog;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.Parameter;
import java.time.Duration;
import java.time.Instant;

/**
 * 请求日志切面
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-12 15:43:40
 */
@Slf4j
@Component
@Aspect
public class RequestLogAspect implements Ordered {

    private HttpServletRequest servletRequest;

    private HttpServletResponse servletResponse;

    private ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    public void setServletRequest(HttpServletRequest servletRequest) {
        this.servletRequest = servletRequest;
    }

    @Autowired
    public void setServletResponse(HttpServletResponse servletResponse) {
        this.servletResponse = servletResponse;
    }

    /**
     * 切入点
     */
    @Pointcut(AspectRule.Rule001.RULE_PATTERN)
    public void pointcut() {
    }

    /**
     * 环绕通知
     */
    @Around("pointcut()")
    public Object doAround(ProceedingJoinPoint point) throws Throwable {
        // 开始时刻
        Instant startInstant = Instant.now();
        MethodSignature methodSignature = (MethodSignature) point.getSignature();
        Method method = methodSignature.getMethod();
        // path
        String requestURI = servletRequest.getRequestURI();
        String requestMethod = servletRequest.getMethod();
        Object[] args = point.getArgs();
        Parameter[] parameters = method.getParameters();
        int status = servletResponse.getStatus();
        // 打印接口请求入参日志
        PrintApiLog.printRequestApiLog(requestURI, requestMethod, parameters, args);
        // 执行被切业务
        Object proceed = point.proceed();
        // 结束时刻
        Instant endInstant = Instant.now();
        Duration between = Duration.between(startInstant, endInstant);
        long millisecond = between.toNanos();
        // 打印接口正常响应参数日志
        PrintApiLog.printResponseApiLog(millisecond, status, requestURI, requestMethod, parameters, args);
        return proceed;
    }

    @Override
    public int getOrder() {
        return AspectRule.Rule001.Order.ORDER_002;
    }

    private boolean isTargetMethod(Method method) {
        return Modifier.isPublic(method.getModifiers())
                && !method.isSynthetic()
                && isMappingMethod(method);
    }

    private boolean isMappingMethod(Method method) {
        return method.isAnnotationPresent(RequestMapping.class)
                || method.isAnnotationPresent(GetMapping.class)
                || method.isAnnotationPresent(PostMapping.class)
                || method.isAnnotationPresent(PutMapping.class)
                || method.isAnnotationPresent(DeleteMapping.class)
                || method.isAnnotationPresent(PatchMapping.class);
    }


}
