package cn.yhm.developer.kuca.panda.model.response;

import cn.yhm.developer.kuca.ecology.model.response.EcologyResponse;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * @author victor2015yhm@gmail.com
 * @since 2023-03-09 20:26:22
 */
@Getter
@Setter
public class GetContentByIdResponse implements EcologyResponse {

    /**
     * 主键
     */
    @JsonProperty(value = "id", index = 1)
    private String id;

    /**
     * 内容
     */
    @JsonProperty(value = "content", index = 2)
    private String content;

    /**
     * 创建时间
     */
    @JsonProperty(value = "create_time", index = 3)
    private String createTime;

}
