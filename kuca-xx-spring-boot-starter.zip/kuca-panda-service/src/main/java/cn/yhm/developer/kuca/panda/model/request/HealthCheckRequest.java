package cn.yhm.developer.kuca.panda.model.request;

import cn.yhm.developer.kuca.ecology.model.request.EcologyRequest;

/**
 * 健康检查请求参数
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-09 00:08:03
 */
public class HealthCheckRequest implements EcologyRequest {
}
