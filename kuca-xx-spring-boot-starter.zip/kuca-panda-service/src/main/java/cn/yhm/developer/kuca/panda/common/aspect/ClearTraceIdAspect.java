package cn.yhm.developer.kuca.panda.common.aspect;


import cn.yhm.developer.kuca.panda.common.constant.AspectRule;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

/**
 * 清除跟踪ID切面
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-12 23:45:46
 */
@Slf4j
@Component
@Aspect
public class ClearTraceIdAspect implements Ordered {

    /**
     * 切入点
     */
    @Pointcut(AspectRule.Rule002.RULE_PATTERN)
    public void pointcut() {
    }

    /**
     * 环绕通知
     */
    @Around("pointcut()")
    public Object doAround(ProceedingJoinPoint point) throws Throwable {
        // 执行被切业务
        Object proceed = point.proceed();
        // 清除当前请求线程中的跟踪ID
        MDC.clear();
        return proceed;
    }

    /**
     * 后置异常通知
     */
    @AfterThrowing("pointcut()")
    public void doAfterThrowing() throws Throwable {
        // 清除当前请求线程中的跟踪ID
        MDC.clear();
    }

    @Override
    public int getOrder() {
        return AspectRule.Rule002.Order.ORDER_001;
    }
}
