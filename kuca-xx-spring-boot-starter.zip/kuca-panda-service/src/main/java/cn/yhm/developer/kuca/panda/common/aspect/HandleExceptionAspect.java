package cn.yhm.developer.kuca.panda.common.aspect;

import cn.yhm.developer.kuca.ecology.model.response.ExceptionResponse;
import cn.yhm.developer.kuca.ecology.model.tip.ErrorTip;
import cn.yhm.developer.kuca.panda.common.enumeration.ErrorReturn;
import cn.yhm.developer.kuca.panda.common.exception.ServiceException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.NoHandlerFoundException;

import javax.servlet.http.HttpServletResponse;
import java.time.ZonedDateTime;
import java.util.HashMap;

/**
 * 全局异常处理切面
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-09-04 21:42:34
 */
@Slf4j
@Component
@RestControllerAdvice
public class HandleExceptionAspect {

    /**
     * 资源未找到异常
     * <p>
     * HTTP Code 404
     *
     * @param e               异常类型 {@link NoHandlerFoundException}
     * @param servletResponse Servlet响应 {@link  HttpServletResponse}
     * @return {@link ExceptionResponse}<{@link ?}>
     */
    @ExceptionHandler(value = {NoHandlerFoundException.class})
    public ExceptionResponse<?> handle(NoHandlerFoundException e,
                                       HttpServletResponse servletResponse) {
        // 错误返回信息
        ErrorReturn errorReturn = ErrorReturn.RESOURCE_NOT_FOUND;
        // 设置响应的HTTP状态码
        servletResponse.setStatus(errorReturn.getErrorType().getHttpStatusCode());
        // 提示信息
        HashMap<String, Object> tipMap = new HashMap<>(3);
        // 设置接口路径
        tipMap.put("path", e.getRequestURL());
        // 设置接口请求方式
        tipMap.put("method", e.getHttpMethod());
        // 设置tip字段
        tipMap.put("tip", errorReturn.getTip());
        return buildExceptionResponse(errorReturn, tipMap);
    }


    /**
     * 请求方法不支持异常
     * <p>
     * HTTP Code 405
     *
     * @param e               异常类型 {@link HttpRequestMethodNotSupportedException}
     * @param servletResponse HttpServlet响应 {@link  HttpServletResponse}
     * @return {@link ExceptionResponse}<{@link ?}>
     */
    @ExceptionHandler(value = HttpRequestMethodNotSupportedException.class)
    public ExceptionResponse<?> handle(HttpRequestMethodNotSupportedException e,
                                       HttpServletResponse servletResponse) {
        // 错误返回信息
        ErrorReturn errorReturn = ErrorReturn.METHOD_NOT_ALLOWED;
        // 设置响应的HTTP状态码
        servletResponse.setStatus(errorReturn.getErrorType().getHttpStatusCode());
        // 提示信息
        HashMap<String, Object> tipMap = new HashMap<>(2);
        // 设置接口请求方式
        tipMap.put("method", e.getMethod());
        // 设置tip字段
        tipMap.put("tip", errorReturn.getTip());
        return buildExceptionResponse(errorReturn, tipMap);
    }


    /**
     * 默认异常处理
     *
     * @param e               异常类型 {@link Exception}
     * @param servletResponse Servlet响应 {@link  HttpServletResponse}
     * @return {@link ExceptionResponse}<{@link ?}>
     */
    @ExceptionHandler(value = Exception.class)
    public ExceptionResponse<?> handle(Exception e, HttpServletResponse servletResponse) {
        // 错误返回信息
        ErrorReturn errorReturn = ErrorReturn.DEFAULT_EXCEPTION;
        // 设置响应的HTTP状态码
        servletResponse.setStatus(errorReturn.getErrorType().getHttpStatusCode());
        return buildExceptionResponse(errorReturn, errorReturn.getTip());
    }

    /**
     * 自定义异常处理
     *
     * @param e               异常类型 {@link ServiceException}
     * @param servletResponse Servlet响应 {@link  HttpServletResponse}
     * @return {@link ExceptionResponse}<{@link ?}>
     */
    @ExceptionHandler(value = ServiceException.class)
    public ExceptionResponse<?> handle(HttpServletResponse servletResponse,
                                       ServiceException e) {
        // 错误返回信息
        ErrorReturn errorReturn = e.getErrorReturn();
        // 设置响应的HTTP状态码
        servletResponse.setStatus(errorReturn.getErrorType().getHttpStatusCode());
        return buildExceptionResponse(errorReturn);
    }

    /**
     * 给ExceptionResponse赋值
     *
     * @param errorReturn 错误返回信息对象 {@link ErrorReturn}
     * @return {@link ExceptionResponse}<{@link ?}>
     */
    private ExceptionResponse<?> buildExceptionResponse(ErrorReturn errorReturn) {
        return buildExceptionResponse(errorReturn, errorReturn.getTip());
    }

    /**
     * 给ExceptionResponse赋值
     *
     * @param errorReturn 错误返回信息对象 {@link ErrorReturn}
     * @param tip         提示信息
     * @return {@link ExceptionResponse}<{@link ?}>
     */
    private <T> ExceptionResponse<?> buildExceptionResponse(ErrorReturn errorReturn, T tip) {
        return ExceptionResponse.builder()
                // 设置错误码
                .errorCode(errorReturn.getErrorCode())
                // HTTP状态码
                .httpStatus(errorReturn.getErrorType().getHttpStatusCode())
                // 设置错误类型
                .errorType(errorReturn.getErrorType().getName())
                // 设置错误 提示信息
                .data(packTip(tip))
                // 设置响应时间戳
                .timestamp(ZonedDateTime.now())
                .build();
    }

    /**
     * 包装Tip字段
     *
     * @param tip 提示字段
     * @return {@link Object}
     */
    private Object packTip(Object tip) {
        if (tip instanceof String) {
            return ErrorTip.build((String) tip);
        }
        if (tip instanceof ErrorTip) {
            return tip;
        }
        if (tip instanceof HashMap) {
            return tip;
        }
        log.warn("Tip field data type is illegal.");
        return null;
    }

}
