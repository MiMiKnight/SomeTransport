package cn.yhm.developer.kuca.validation;

import java.lang.annotation.Annotation;

/**
 * @author victor2015yhm@gmail.com
 * @since 2023-03-05 22:19:43
 */
public interface ConstraintValidator<A extends Annotation, T> {

    /**
     * 初始化方法
     *
     * @param constraintAnnotation 校验注解
     */
    default void initialize(A constraintAnnotation) {
    }

    /**
     * 校验方法
     *
     * @param value 被校验参数值
     * @return boolean
     */
    boolean isValid(T value);
}