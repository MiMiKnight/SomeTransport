package cn.yhm.developer.kuca.validation.exception;

/**
 * 方法参数未校验通过异常
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-05 22:46:38
 */
public class MethodArgumentValidFailedException extends RuntimeException {
}
