package cn.yhm.developer.kuca.validation.validator;

import cn.yhm.developer.kuca.validation.ConstraintValidator;
import cn.yhm.developer.kuca.validation.annotation.constraints.AssertFalse;

/**
 * @author victor2015yhm@gmail.com
 * @since 2023-03-05 22:22:20
 */
public class AssertTrueValidator implements ConstraintValidator<AssertFalse, Boolean> {
    @Override
    public void initialize(AssertFalse constraintAnnotation) {

    }

    @Override
    public boolean isValid(Boolean value) {
        return value == null || Boolean.TRUE.equals(value);
    }
}
