package cn.yhm.developer.kuca.common.utils.standard;


import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;

/**
 * HTTP工具类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-07 18:02:17
 */
public interface HttpService {

    /**
     * 缺省HTTP头
     *
     * @return {@link HttpHeaders}
     */
    HttpHeaders defaultHttpHeaders();

    /**
     * JSON类型的HTTP头
     * <p>
     * Content-Type = application/json
     *
     * @return {@link HttpHeaders}
     */
    HttpHeaders jsonContentTypeHttpHeaders();

    /**
     * 拼接请求参数到请求路径中
     *
     * @param uri    统一资源标识符
     * @param params 请求行参数
     * @return {@link String}
     */
    String concatParamToPath(String uri, HashMap<String, Object> params);

    /**
     * 执行HTTP请求
     *
     * @param uri     统一资源标识符
     * @param method  请求方式
     * @param headers 请求头
     * @param body    请求体
     * @return {@link ResponseEntity}<{@link String}>
     */
    <T> ResponseEntity<String> doHttp(String uri, HttpMethod method, HttpHeaders headers, T body);

    /**
     * 执行HTTP请求
     *
     * @param apiDomain 接口域名前缀
     * @param apiPath   接口路径
     * @param method    请求方式
     * @param headers   请求头
     * @param body      请求体
     * @return {@link ResponseEntity}<{@link String}>
     */
    <T> ResponseEntity<String> doHttp(String apiDomain, String apiPath, HttpMethod method, HttpHeaders headers, T body);

    /**
     * 执行HTTP请求
     *
     * @param uri          统一资源标识符
     * @param method       请求方式
     * @param headers      请求头
     * @param body         请求体
     * @param uriVariables uri变量
     * @return {@link ResponseEntity}<{@link String}>
     */
    <T> ResponseEntity<String> doHttp(String uri, HttpMethod method, HttpHeaders headers, T body,
                                      Object... uriVariables);

    /**
     * 执行HTTP请求
     *
     * @param apiDomain    接口域名前缀
     * @param apiPath      接口路径
     * @param method       请求方式
     * @param headers      请求头
     * @param body         请求体
     * @param uriVariables uri变量
     * @return {@link ResponseEntity}<{@link String}>
     */
    <T> ResponseEntity<String> doHttp(String apiDomain, String apiPath, HttpMethod method, HttpHeaders headers, T body,
                                      Object... uriVariables);

    /**
     * Get请求
     *
     * @param uri     统一资源标识符
     * @param headers 请求头
     * @return {@link ResponseEntity}<{@link String}>
     */
    ResponseEntity<String> doGet(String uri, HttpHeaders headers);

    /**
     * Get请求
     *
     * @param apiDomain 接口域名前缀
     * @param apiPath   接口路径
     * @param headers   请求头
     * @return {@link ResponseEntity}<{@link String}>
     */
    ResponseEntity<String> doGet(String apiDomain, String apiPath, HttpHeaders headers);

    /**
     * Get请求
     *
     * @param uri     统一资源标识符
     * @param headers 请求头
     * @param params  请求行参数
     * @return {@link ResponseEntity}<{@link String}>
     */
    ResponseEntity<String> doGet(String uri, HttpHeaders headers, HashMap<String, Object> params);

    /**
     * Get请求
     *
     * @param apiDomain 接口域名前缀
     * @param apiPath   接口路径
     * @param headers   请求头
     * @param params    请求行参数
     * @return {@link ResponseEntity}<{@link String}>
     */
    ResponseEntity<String> doGet(String apiDomain, String apiPath, HttpHeaders
            headers, HashMap<String, Object> params);

    /**
     * Get请求
     *
     * @param uri          统一资源标识符
     * @param headers      请求头
     * @param params       请求行参数
     * @param uriVariables 路径占位符值
     * @return {@link ResponseEntity}<{@link String}>
     */
    ResponseEntity<String> doGet(String uri, HttpHeaders headers, HashMap<String, Object> params, Object...
            uriVariables);

    /**
     * Get请求
     *
     * @param apiDomain    接口域名前缀
     * @param apiPath      接口路径
     * @param headers      请求头
     * @param params       请求行参数
     * @param uriVariables 路径占位符值
     * @return {@link ResponseEntity}<{@link String}>
     */
    ResponseEntity<String> doGet(String apiDomain, String apiPath, HttpHeaders
            headers, HashMap<String, Object> params, Object... uriVariables);

    /**
     * Post请求
     *
     * @param uri     统一资源标识符
     * @param headers 请求头
     * @param body    请求体
     * @return {@link String}
     */
    <T> ResponseEntity<String> doPost(String uri, HttpHeaders headers, T body);

    /**
     * Post请求
     *
     * @param apiDomain 接口域名前缀
     * @param apiPath   接口路径
     * @param headers   请求头
     * @param body      请求体
     * @return {@link ResponseEntity}<{@link String}>
     */
    <T> ResponseEntity<String> doPost(String apiDomain, String apiPath, HttpHeaders headers, T body);

    /**
     * Put请求
     *
     * @param uri     统一资源标识符
     * @param headers 请求头
     * @param body    请求体
     * @return {@link String}
     */
    <T> ResponseEntity<String> doPut(String uri, HttpHeaders headers, T body);

    /**
     * Put请求
     *
     * @param apiDomain 接口域名前缀
     * @param apiPath   接口路径
     * @param headers   请求头
     * @param body      请求体
     * @return {@link ResponseEntity}<{@link String}>
     */
    <T> ResponseEntity<String> doPut(String apiDomain, String apiPath, HttpHeaders headers, T body);

    /**
     * Delete请求
     *
     * @param uri     统一资源标识符
     * @param headers 请求头
     * @param body    请求体
     * @return {@link String}
     */
    <T> ResponseEntity<String> doDelete(String uri, HttpHeaders headers, T body);

    /**
     * Delete请求
     *
     * @param apiDomain 接口域名前缀
     * @param apiPath   接口路径
     * @param headers   请求头
     * @param body      请求体
     * @return {@link ResponseEntity}<{@link String}>
     */
    <T> ResponseEntity<String> doDelete(String apiDomain, String apiPath, HttpHeaders headers, T body);

    /**
     * Patch请求
     *
     * @param uri     统一资源标识符
     * @param headers 请求头
     * @param body    请求体
     * @return {@link String}
     */
    <T> ResponseEntity<String> doPatch(String uri, HttpHeaders headers, T body);

    /**
     * Patch请求
     *
     * @param apiDomain 接口域名前缀
     * @param apiPath   接口路径
     * @param headers   请求头
     * @param body      请求体
     * @return {@link ResponseEntity}<{@link String}>
     */
    <T> ResponseEntity<String> doPatch(String apiDomain, String apiPath, HttpHeaders headers, T body);

    /**
     * Options请求
     *
     * @param uri     统一资源标识符
     * @param headers 请求头
     * @param body    请求体
     * @return {@link String}
     */
    <T> ResponseEntity<String> doOptions(String uri, HttpHeaders headers, T body);

    /**
     * Options请求
     *
     * @param apiDomain 接口域名前缀
     * @param apiPath   接口路径
     * @param headers   请求头
     * @param body      请求体
     * @return {@link ResponseEntity}<{@link String}>
     */
    <T> ResponseEntity<String> doOptions(String apiDomain, String apiPath, HttpHeaders headers, T body);

}
