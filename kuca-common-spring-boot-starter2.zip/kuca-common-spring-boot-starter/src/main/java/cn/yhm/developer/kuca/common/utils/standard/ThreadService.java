package cn.yhm.developer.kuca.common.utils.standard;

/**
 * 多线程工具类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-07 17:41:54
 */
public interface ThreadService {

    /**
     * 异步线程
     *
     * @param command 异步执行内容
     */
    void async(Runnable command);
}
