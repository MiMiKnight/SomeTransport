package cn.yhm.developer.kuca.common.utils.impl;

import cn.yhm.developer.kuca.common.utils.standard.HttpService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.HashMap;

/**
 * HTTP工具实现类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-07 18:04:12
 */
@Component
public class HttpServiceImpl implements HttpService {

    private RestTemplate restTemplate;

    @Autowired
    public void setRestTemplate(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Override
    public HttpHeaders defaultHttpHeaders() {
        return new HttpHeaders();
    }

    @Override
    public HttpHeaders jsonContentTypeHttpHeaders() {
        HttpHeaders headers = defaultHttpHeaders();
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        return headers;
    }

    @Override
    public String concatParamToPath(String uri, HashMap<String, Object> params) {
        if (StringUtils.isBlank(uri) || null == params || params.size() < 1) {
            return uri;
        }
        UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromPath(uri);
        params.forEach(uriBuilder::queryParam);
        return uriBuilder.toUriString();
    }

    @Override
    public <T> ResponseEntity<String> doHttp(String uri, HttpMethod method, HttpHeaders headers, T body) {
        HttpEntity<T> httpEntity = new HttpEntity<>(body, headers);
        return restTemplate.exchange(uri, method, httpEntity, String.class);
    }

    @Override
    public <T> ResponseEntity<String> doHttp(String apiDomain, String apiPath, HttpMethod method, HttpHeaders headers, T body) {
        String uri = apiDomain + apiPath;
        return doHttp(uri, method, headers, body);
    }

    @Override
    public <T> ResponseEntity<String> doHttp(String uri, HttpMethod method, HttpHeaders headers, T body, Object... uriVariables) {
        HttpEntity<T> httpEntity = new HttpEntity<>(body, headers);
        return restTemplate.exchange(uri, method, httpEntity, String.class, uriVariables);
    }

    @Override
    public <T> ResponseEntity<String> doHttp(String apiDomain, String apiPath, HttpMethod method, HttpHeaders headers, T body, Object... uriVariables) {
        String uri = apiDomain + apiPath;
        return doHttp(uri, method, headers, body, uriVariables);
    }

    @Override
    public ResponseEntity<String> doGet(String uri, HttpHeaders headers) {
        HttpEntity<Object> httpEntity = new HttpEntity<>(headers);
        return restTemplate.exchange(uri, HttpMethod.GET, httpEntity, String.class);
    }

    @Override
    public ResponseEntity<String> doGet(String apiDomain, String apiPath, HttpHeaders headers) {
        String uri = apiDomain + apiPath;
        return doGet(uri, headers);
    }

    @Override
    public ResponseEntity<String> doGet(String uri, HttpHeaders headers, HashMap<String, Object> params) {
        uri = concatParamToPath(uri, params);
        HttpEntity<Object> httpEntity = new HttpEntity<>(headers);
        return restTemplate.exchange(uri, HttpMethod.GET, httpEntity, String.class);
    }

    @Override
    public ResponseEntity<String> doGet(String apiDomain, String apiPath, HttpHeaders headers, HashMap<String, Object> params) {
        String uri = apiDomain + apiPath;
        return doGet(uri, headers, params);
    }

    @Override
    public ResponseEntity<String> doGet(String uri, HttpHeaders headers, HashMap<String, Object> params, Object... uriVariables) {
        uri = concatParamToPath(uri, params);
        HttpEntity<Object> httpEntity = new HttpEntity<>(headers);
        return restTemplate.exchange(uri, HttpMethod.GET, httpEntity, String.class, uriVariables);
    }

    @Override
    public ResponseEntity<String> doGet(String apiDomain, String apiPath, HttpHeaders headers, HashMap<String, Object> params, Object... uriVariables) {
        String uri = apiDomain + apiPath;
        return doGet(uri, headers, params, uriVariables);
    }

    @Override
    public <T> ResponseEntity<String> doPost(String uri, HttpHeaders headers, T body) {
        return doHttp(uri, HttpMethod.POST, headers, body);
    }

    @Override
    public <T> ResponseEntity<String> doPost(String apiDomain, String apiPath, HttpHeaders headers, T body) {
        String uri = apiDomain + apiPath;
        return doPost(uri, headers, body);
    }

    @Override
    public <T> ResponseEntity<String> doPut(String uri, HttpHeaders headers, T body) {
        return doHttp(uri, HttpMethod.PUT, headers, body);
    }

    @Override
    public <T> ResponseEntity<String> doPut(String apiDomain, String apiPath, HttpHeaders headers, T body) {
        String uri = apiDomain + apiPath;
        return doPut(uri, headers, body);
    }

    @Override
    public <T> ResponseEntity<String> doDelete(String uri, HttpHeaders headers, T body) {
        return doHttp(uri, HttpMethod.DELETE, headers, body);
    }

    @Override
    public <T> ResponseEntity<String> doDelete(String apiDomain, String apiPath, HttpHeaders headers, T body) {
        String uri = apiDomain + apiPath;
        return doDelete(uri, headers, body);
    }

    @Override
    public <T> ResponseEntity<String> doPatch(String uri, HttpHeaders headers, T body) {
        return doHttp(uri, HttpMethod.PATCH, headers, body);
    }

    @Override
    public <T> ResponseEntity<String> doPatch(String apiDomain, String apiPath, HttpHeaders headers, T body) {
        String uri = apiDomain + apiPath;
        return doPatch(uri, headers, body);
    }

    @Override
    public <T> ResponseEntity<String> doOptions(String uri, HttpHeaders headers, T body) {
        return doHttp(uri, HttpMethod.OPTIONS, headers, body);
    }

    @Override
    public <T> ResponseEntity<String> doOptions(String apiDomain, String apiPath, HttpHeaders headers, T body) {
        String uri = apiDomain + apiPath;
        return doOptions(uri, headers, body);
    }
}
