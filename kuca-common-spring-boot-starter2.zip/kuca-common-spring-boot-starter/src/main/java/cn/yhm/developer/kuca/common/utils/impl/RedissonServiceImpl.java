package cn.yhm.developer.kuca.common.utils.impl;

import cn.yhm.developer.kuca.common.utils.standard.RedissonService;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

/**
 * Redisson分布式锁工具类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-24 20:41:17
 */
@Component
public class RedissonServiceImpl implements RedissonService {

    private RedissonClient redissonClient;

    @Autowired
    public void setRedissonClient(RedissonClient redissonClient) {
        this.redissonClient = redissonClient;
    }

    @Override
    public RLock lock(String lockKey, TimeUnit unit, long expireTime) {
        RLock lock = redissonClient.getLock(lockKey);
        lock.lock(expireTime, unit);
        return lock;
    }

    @Override
    public RLock lock(String lockKey, long expireTime) {
        RLock lock = redissonClient.getLock(lockKey);
        lock.lock(expireTime, TimeUnit.SECONDS);
        return lock;
    }

    @Override
    public RLock lock(String lockKey) {
        RLock lock = redissonClient.getLock(lockKey);
        lock.lock();
        return lock;
    }

    @Override
    public boolean tryLock(String lockKey, long waitTime, TimeUnit unit) {
        RLock lock = redissonClient.getLock(lockKey);
        try {
            return lock.tryLock(waitTime, unit);
        } catch (InterruptedException e) {
            return false;
        }
    }

    @Override
    public boolean tryLock(String lockKey, long waitTime, long expireTime) {
        return this.tryLock(lockKey, TimeUnit.SECONDS, waitTime, expireTime);
    }

    @Override
    public boolean tryLock(String lockKey, TimeUnit unit, long waitTime, long expireTime) {
        RLock lock = redissonClient.getLock(lockKey);
        try {
            return lock.tryLock(waitTime, expireTime, unit);
        } catch (InterruptedException e) {
            return false;
        }
    }

    @Override
    public void unlock(String lockKey) {
        RLock lock = redissonClient.getLock(lockKey);
        if (!lock.isLocked()) {
            return;
        }
        lock.unlock();
    }

    @Override
    public void unlock(RLock lock) {
        if (!lock.isLocked()) {
            return;
        }
        lock.unlock();
    }
}
