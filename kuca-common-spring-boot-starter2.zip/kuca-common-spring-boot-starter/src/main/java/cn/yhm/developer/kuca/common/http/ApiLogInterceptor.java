package cn.yhm.developer.kuca.common.http;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

/**
 * Api接口日志拦截器
 * <p>
 * 用途：调用第三方接口时，打印接口的请求入参和响应出参日志
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-06 22:30:07
 */
@Slf4j
public class ApiLogInterceptor implements ClientHttpRequestInterceptor {

    interface LocalConstant {
        String MDC_TRACE_ID_KEY = "TRACE_ID";
    }

    /**
     * 拦截
     *
     * @param request   请求
     * @param body      请求体
     * @param execution 执行器
     * @return {@link ClientHttpResponse}
     * @throws IOException ioexception
     */
    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body,
                                        ClientHttpRequestExecution execution) throws IOException {
        // 设置当前请求线程中的跟踪ID
        String uuid = UUID.randomUUID().toString().replace("-", "");
        MDC.put(LocalConstant.MDC_TRACE_ID_KEY, uuid);

        traceRequest(request, body);
        ClientHttpResponse response = execution.execute(request, body);
        traceResponse(response);

        // 清除当前请求线程中的跟踪ID
        MDC.clear();
        return response;
    }

    /**
     * 跟踪请求
     *
     * @param request 请求
     * @param body    请求体
     */
    private void traceRequest(HttpRequest request, byte[] body) {
        log.info("===============================Request Begin===============================");
        log.info("URI         : {}", request.getURI());
        log.info("Method      : {}", request.getMethod());
        log.info("Headers     : {}", request.getHeaders());
        log.info("Request body: {}", new String(body, StandardCharsets.UTF_8));
        log.info("===============================Request End=================================");
    }

    /**
     * 跟踪响应
     *
     * @param response 响应
     * @throws IOException ioexception
     */
    private void traceResponse(ClientHttpResponse response) throws IOException {
        StringBuilder inputStringBuilder = new StringBuilder();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(response.getBody(), StandardCharsets.UTF_8));
        String line = bufferedReader.readLine();
        while (line != null) {
            inputStringBuilder.append(line);
            inputStringBuilder.append(' ');
            line = bufferedReader.readLine();
        }
        log.info("===============================Response Begin==============================");
        log.info("Status code  : {}", response.getStatusCode());
        log.info("Status text  : {}", response.getStatusText());
        log.info("Headers      : {}", response.getHeaders());
        log.info("Response body: {}", inputStringBuilder);
        log.info("===============================Response End================================");
    }
}
