package cn.yhm.developer.kuca.common.config;

import cn.yhm.developer.kuca.common.http.ApiLogInterceptor;
import cn.yhm.developer.kuca.common.http.CustomResponseErrorHandler;
import cn.yhm.developer.kuca.common.properties.OkHttpProperties;
import okhttp3.ConnectionPool;
import okhttp3.OkHttpClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.OkHttp3ClientHttpRequestFactory;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * RestTemplate配置类
 * <p>
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-06 21:44:12
 */
@EnableConfigurationProperties(OkHttpProperties.class)
@Configuration
public class RestTemplateConfig {

    private OkHttpProperties okHttpProperties;

    @Autowired
    public void setOkHttpProperties(OkHttpProperties okHttpProperties) {
        this.okHttpProperties = okHttpProperties;
    }

    /**
     * RestTemplate
     *
     * @return {@link RestTemplate}
     */
    @Bean(name = "restTemplate")
    public RestTemplate restTemplate(ClientHttpRequestFactory httpRequestFactory) {
        // TODO: 1、解决HTTPS访问的问题
        // TODO: 2、解决响应body为空的问题
        return new RestTemplateBuilder()
                .interceptors(httpRequestInterceptorList())
                .errorHandler(responseErrorHandler())
                .requestFactory(() -> httpRequestFactory)
                .build();
    }

    /**
     * 连接池
     *
     * @return {@link ConnectionPool}
     */
    @Bean("HttpConnectionPool")
    public ConnectionPool connectionPool() {
        // 最大空闲连接
        int maxIdleConnections = okHttpProperties.getMaxIdleConnections();
        // 连接持续时间
        long keepAliveDuration = okHttpProperties.getKeepAliveDuration();
        // 连接持续时间单位
        TimeUnit keepAliveDurationTimeUnit = okHttpProperties.getKeepAliveDurationTimeUnit();

        return new ConnectionPool(maxIdleConnections, keepAliveDuration, keepAliveDurationTimeUnit);
    }

    /**
     * http客户端
     *
     * @return {@link OkHttpClient}
     */
    @Bean("OkHttp3Client")
    public OkHttpClient okHttp3Client(ConnectionPool pool) {
        // 连接超时时间
        long connectTimeout = okHttpProperties.getConnectTimeout();
        // 连接超时时间 单位
        TimeUnit connectTimeoutTimeUnit = okHttpProperties.getConnectTimeoutTimeUnit();

        // 读超时时间
        long readTimeout = okHttpProperties.getReadTimeout();
        // 读超时时间 单位
        TimeUnit readTimeoutTimeUnit = okHttpProperties.getReadTimeoutTimeUnit();

        // 写超时时间
        long writeTimeout = okHttpProperties.getWriteTimeout();
        // 写超时时间 单位
        TimeUnit writeTimeoutTimeUnit = okHttpProperties.getWriteTimeoutTimeUnit();

        // 调用超时时间
        long callTimeout = okHttpProperties.getCallTimeout();
        // 调用超时时间 单位
        TimeUnit callTimeoutTimeUnit = okHttpProperties.getCallTimeoutTimeUnit();

        return new OkHttpClient().newBuilder()
                .connectionPool(pool)
                .connectTimeout(connectTimeout, connectTimeoutTimeUnit)
                .readTimeout(readTimeout, readTimeoutTimeUnit)
                .writeTimeout(writeTimeout, writeTimeoutTimeUnit)
                .callTimeout(callTimeout, callTimeoutTimeUnit)
                .hostnameVerifier((hostname, sslSession) -> true) // 信任所有的证书与主机
                .followRedirects(false) // 禁止重定向
                .build();
    }

    /**
     * http请求工厂
     *
     * @return {@link OkHttp3ClientHttpRequestFactory}
     */
    @Bean("OkHttp3ClientHttpRequestFactory")
    public OkHttp3ClientHttpRequestFactory httpRequestFactory(OkHttpClient okHttpClient) {
        return new OkHttp3ClientHttpRequestFactory(okHttpClient);
    }

    /**
     * 响应错误处理器
     *
     * @return {@link ResponseErrorHandler}
     */
    private ResponseErrorHandler responseErrorHandler() {
        return new CustomResponseErrorHandler();
    }

    /**
     * http请求拦截器
     *
     * @return {@link List}<{@link ClientHttpRequestInterceptor}>
     */
    private List<ClientHttpRequestInterceptor> httpRequestInterceptorList() {
        // 拦截器集合
        List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
        // 添加接口日志打印拦截器
        interceptors.add(new ApiLogInterceptor());
        return interceptors;
    }

}
