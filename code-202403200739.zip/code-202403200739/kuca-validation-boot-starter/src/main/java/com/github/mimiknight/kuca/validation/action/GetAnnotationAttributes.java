package com.github.mimiknight.kuca.validation.action;

import com.github.mimiknight.kuca.validation.exception.KucaValidationException;
import org.apache.commons.collections4.MapUtils;
import org.springframework.util.ReflectionUtils;

import java.lang.annotation.Annotation;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.PrivilegedAction;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * 获取注解属性
 *
 * @author MiMiKnight victor2015yhm@gmail.com
 * @since 2023-12-20 07:28:40
 */
public final class GetAnnotationAttributes implements PrivilegedAction<Map<String, Object>> {

    private final Annotation annotation;

    public static GetAnnotationAttributes action(Annotation annotation) {
        return new GetAnnotationAttributes(annotation);
    }

    private GetAnnotationAttributes(Annotation annotation) {
        this.annotation = annotation;
    }

    /**
     * 获取注解属性Map集合
     */
    @Override
    public Map<String, Object> run() {
        Method[] methods = annotation.annotationType().getDeclaredMethods();
        Map<String, Object> attributes = new HashMap<>(methods.length);

        for (Method method : methods) {
            // Exclude synthetic methods
            if (method.isSynthetic()) {
                continue;
            }
            if (!method.canAccess(annotation)) {
                ReflectionUtils.makeAccessible(method);
            }
            String attributeName = method.getName();
            try {
                attributes.put(method.getName(), method.invoke(annotation));
            } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                String format = "Unable to resolve attribute '%2$s' from annotation '%1$s'";
                String message = String.format(format, annotation.getClass(), attributeName);
                throw new KucaValidationException(message, e);
            }
        }
        return toImmutableMap(attributes);
    }

    private <K, V> Map<K, V> toImmutableMap(Map<K, V> map) {
        if (MapUtils.isEmpty(map)) {
            return Collections.emptyMap();
        }
        return Collections.unmodifiableMap(map);
    }

}
