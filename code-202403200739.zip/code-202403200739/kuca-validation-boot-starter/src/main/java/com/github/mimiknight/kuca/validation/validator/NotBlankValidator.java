package com.github.mimiknight.kuca.validation.validator;

import com.github.mimiknight.kuca.validation.annotation.validation.KucaNotBlank;
import org.apache.commons.lang3.StringUtils;

/**
 * 非空白字符串校验器
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-06-07 20:13:23
 */
public class NotBlankValidator implements ConstraintValidator<KucaNotBlank, Object> {

    @Override
    public boolean isValid(Object value) {
        if (null == value) {
            return false;
        }
        if (value instanceof String result) {
            return StringUtils.isNotBlank(result);
        }
        // 默认放通
        return true;
    }
}
