package com.github.mimiknight.kuca.validation.validator;

import com.github.mimiknight.kuca.validation.annotation.validation.KucaUniqueElements;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.HashSet;
import java.util.Locale;

/**
 * 元素唯一性校验注解校验器
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-06-07 20:13:23
 */
public class UniqueElementsValidator implements ConstraintValidator<KucaUniqueElements, Object> {

    private boolean caseSensitive = true;

    @Override
    public void initialize(KucaUniqueElements constraintAnnotation) {
        this.caseSensitive = constraintAnnotation.caseSensitive();
    }

    @Override
    public boolean isValid(Object value) {
        if (null == value) {
            return true;
        }
        // 数组
        if (value.getClass().isArray()) {
            if (Array.getLength(value) <= 1) {
                return true;
            }
            return valid((Object[]) value);
        }
        // 单列集合
        if (value instanceof Collection<?> list) {
            if (list.size() <= 1) {
                return true;
            }
            return valid(list.toArray());
        }
        // 默认放通
        return true;
    }

    private <T> boolean valid(T[] values) {
        HashSet<Object> set = new HashSet<>();
        for (Object value : values) {
            // 大小写不敏感
            if (!caseSensitive) {
                // 字符串对象
                if (value instanceof String result) {
                    value = result.toLowerCase(Locale.ROOT);
                }
                // 字符对象
                if (value instanceof Character result) {
                    value = Character.toLowerCase(result);
                }
            }
            if (!set.add(value)) {
                return false;
            }
        }
        return true;
    }

}
