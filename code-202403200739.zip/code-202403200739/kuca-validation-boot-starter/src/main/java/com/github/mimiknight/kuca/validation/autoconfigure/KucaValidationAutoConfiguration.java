package com.github.mimiknight.kuca.validation.autoconfigure;

import com.github.mimiknight.kuca.validation.properties.KucaValidationProperties;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

/**
 * 自动配置类
 *
 * @author MiMiKnight victor2015yhm@gmail.com
 * @since 2024-03-06 07:45:02
 */
@AutoConfiguration
@EnableConfigurationProperties(value = {KucaValidationProperties.class})
public class KucaValidationAutoConfiguration {
}
