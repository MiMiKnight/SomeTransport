package com.github.mimiknight.kuca.validation.exception;

public class KucaValidationException extends RuntimeException {

    private static final long serialVersionUID = -3664684893897729208L;

    public KucaValidationException(String message) {
        super(message);
    }

    public KucaValidationException() {
        super();
    }

    public KucaValidationException(String message, Throwable cause) {
        super(message, cause);
    }

    public KucaValidationException(Throwable cause) {
        super(cause);
    }
}
