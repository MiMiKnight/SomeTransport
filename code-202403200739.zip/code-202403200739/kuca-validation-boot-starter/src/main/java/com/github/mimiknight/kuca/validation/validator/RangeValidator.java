package com.github.mimiknight.kuca.validation.validator;

import com.github.mimiknight.kuca.validation.annotation.validation.KucaRange;

/**
 * 元素大小范围注解校验器
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-06-07 20:13:23
 */
public class RangeValidator implements ConstraintValidator<KucaRange, Object> {

    private double min;
    private double max;
    private double delta;

    @Override
    public void initialize(KucaRange constraintAnnotation) {
        this.min = constraintAnnotation.min();
        this.max = constraintAnnotation.max();
        this.delta = constraintAnnotation.delta();
    }

    @Override
    public boolean isValid(Object value) {
        if (null == value) {
            return true;
        }
        if (value instanceof Number result) {
            double doubleValue = result.doubleValue();
            return ((Double.compare(doubleValue, max) < 0) || (Math.abs(doubleValue - max) < delta))
                    && ((Double.compare(doubleValue, min) > 0) || (Math.abs(doubleValue - min) < delta));
        }
        // 默认放通
        return true;
    }
}
