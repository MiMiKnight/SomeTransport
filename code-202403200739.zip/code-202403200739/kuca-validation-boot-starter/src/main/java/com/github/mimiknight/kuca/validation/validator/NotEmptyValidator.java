package com.github.mimiknight.kuca.validation.validator;

import com.github.mimiknight.kuca.validation.annotation.validation.KucaNotEmpty;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;

/**
 * 参数非空校验器
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-06-07 20:13:23
 */
public class NotEmptyValidator implements ConstraintValidator<KucaNotEmpty, Object> {

    @Override
    public boolean isValid(Object value) {
        if (null == value) {
            return false;
        }
        // 字符串
        if (value instanceof String result) {
            return StringUtils.isNotEmpty(result);
        }
        // 数组
        if (value.getClass().isArray()) {
            return Array.getLength(value) >= 1;
        }
        // 单列集合
        if (value instanceof Collection<?> list) {
            return CollectionUtils.isNotEmpty(list);
        }
        // 双列集合
        if (value instanceof Map<?, ?> map) {
            return MapUtils.isNotEmpty(map);
        }
        // 默认放通
        return true;
    }

}
