package com.github.mimiknight.kuca.validation.properties;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "kuca.app.validation", ignoreInvalidFields = true)
public class KucaValidationProperties {

}
