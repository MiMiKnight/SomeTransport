package com.github.mimiknight.kuca.validation.utils;

import com.github.mimiknight.kuca.validation.action.ConstraintAnnotationDescriptor;
import com.github.mimiknight.kuca.validation.action.ConstraintHelper;
import com.github.mimiknight.kuca.validation.exception.KucaMethodArgumentValidationException;
import com.github.mimiknight.kuca.validation.model.ValidationPayload;
import com.github.mimiknight.kuca.validation.validator.ConstraintValidator;
import org.apache.commons.collections4.CollectionUtils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.List;

/**
 * Kuca参数校验工具类
 *
 * @author MiMiKnight victor2015yhm@gmail.com
 * @since 2024-03-17 15:58:47
 */
public final class KucaValidationUtils {

    private KucaValidationUtils() {
    }

    /**
     * 对象的注解参数校验
     *
     * @param target 目标
     */
    public static void valid(Object target) {
        List<Field> fields = ConstraintHelper.getFields(target);
        if (CollectionUtils.isEmpty(fields)) {
            return;
        }
        for (Field field : fields) {
            validField(field, target);
        }
    }

    /**
     * 字段的注解参数校验
     *
     * @param field  待校验的反射字段
     * @param target 目标对象
     */
    public static void validField(Field field, Object target) {
        Object value = ConstraintHelper.getFieldValue(target, field);
        List<Annotation> constraintAnnotations = ConstraintHelper.getConstraintAnnotation(field);
        if (CollectionUtils.isEmpty(constraintAnnotations)) {
            return;
        }
        for (Annotation constraint : constraintAnnotations) {
            List<ConstraintValidator<Annotation, Object>> validators = ConstraintHelper.getValidators(constraint);
            if (CollectionUtils.isEmpty(validators)) {
                continue;
            }
            for (ConstraintValidator<Annotation, Object> validator : validators) {
                if (validator.isValid(value)) {
                    continue;
                }
                throw buildMethodArgumentValidationException(field, value, constraint);
            }
        }
        // 若被字段KucaValidated注解装饰则执行递归校验
        if (ConstraintHelper.decorateByKucaValidated(field)) {
            KucaValidationUtils.valid(value);
        }
    }

    /**
     * 构建方法参数验证异常
     *
     * @param field      字段对象
     * @param value      字段值
     * @param constraint 约束注解
     * @return {@link KucaMethodArgumentValidationException}
     */
    private static KucaMethodArgumentValidationException buildMethodArgumentValidationException(Field field, Object value, Annotation constraint) {
        return buildMethodArgumentValidationException(field, value, -1, constraint);
    }

    /**
     * 构建方法参数验证异常
     *
     * @param field      字段对象
     * @param value      字段值
     * @param index      字段索引
     * @param constraint 约束注解
     * @return {@link KucaMethodArgumentValidationException}
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    private static KucaMethodArgumentValidationException buildMethodArgumentValidationException(Field field, Object value, Integer index, Annotation constraint) {
        ConstraintAnnotationDescriptor descriptor = new ConstraintAnnotationDescriptor.Builder()
                .setAnnotation(constraint).build();
        // 错误提示消息
        String message = ConstraintHelper.getValidationMessage(descriptor);
        // 错误码
        String errorCode = descriptor.getErrorCode();
        return new KucaMethodArgumentValidationException(message, buildValidationPayload(index, field, value, message, errorCode));
    }

    /**
     * 生成验证有效负载
     *
     * @param index     参数索引
     * @param field     被校验参数字段对象
     * @param value     被校验字段值
     * @param message   消息
     * @param errorCode 错误码
     * @return {@link ValidationPayload}
     */
    private static ValidationPayload buildValidationPayload(Integer index, Field field, Object value, String message, String errorCode) {
        ValidationPayload payload = new ValidationPayload();
        payload.setIndex(index);
        payload.setField(field);
        payload.setMessage(message);
        payload.setErrorCode(errorCode);
        payload.setValue(value);
        return payload;
    }


}
