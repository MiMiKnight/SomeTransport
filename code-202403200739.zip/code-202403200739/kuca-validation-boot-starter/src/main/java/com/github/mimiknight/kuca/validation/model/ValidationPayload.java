package com.github.mimiknight.kuca.validation.model;

import lombok.Getter;
import lombok.Setter;

import java.lang.reflect.Field;

/**
 * 校验信息负载
 *
 * @author MiMiKnight victor2015yhm@gmail.com
 * @since 2024-03-17 22:15:49
 */
@Getter
@Setter
public class ValidationPayload {

    /**
     * 被校验字段
     */
    private Field field = null;

    /**
     * 被校验参数索引
     */
    private Integer index = -1;

    /**
     * 被校验字段的值
     */
    private Object value;

    /**
     * 错误码
     */
    private String errorCode = "";

    /**
     * 错误提示消息
     */
    private String message = "";

}
