package com.github.mimiknight.kuca.validation.validator;

import com.github.mimiknight.kuca.validation.annotation.validation.KucaLength;

/**
 * 字符串长度校验器
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-06-07 20:13:23
 */
public class LengthValidator implements ConstraintValidator<KucaLength, Object> {

    private int min;
    private int max;

    @Override
    public void initialize(KucaLength constraintAnnotation) {
        this.min = constraintAnnotation.min();
        this.max = constraintAnnotation.max();
    }

    @Override
    public boolean isValid(Object value) {
        if (null == value) {
            return true;
        }
        if (value instanceof String result) {
            int size = result.length();
            return (size >= min && size <= max);
        }
        // 默认放通
        return true;
    }
}
