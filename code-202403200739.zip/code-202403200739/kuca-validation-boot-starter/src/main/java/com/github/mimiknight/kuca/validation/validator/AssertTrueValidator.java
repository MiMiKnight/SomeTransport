package com.github.mimiknight.kuca.validation.validator;

import com.github.mimiknight.kuca.validation.annotation.validation.KucaAssertTrue;

/**
 * 参数为true校验器
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-06-07 20:13:23
 */
public class AssertTrueValidator implements ConstraintValidator<KucaAssertTrue, Object> {

    @Override
    public boolean isValid(Object value) {
        if (null == value) {
            return true;
        }
        if (value instanceof Boolean result) {
            return Boolean.TRUE.equals(result);
        }
        // 默认放通
        return true;
    }
}
