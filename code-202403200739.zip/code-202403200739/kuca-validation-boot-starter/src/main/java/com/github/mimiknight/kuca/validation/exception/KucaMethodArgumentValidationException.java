package com.github.mimiknight.kuca.validation.exception;

import com.github.mimiknight.kuca.validation.model.ValidationPayload;
import lombok.Getter;

import java.io.Serial;

/**
 * 方法参数校验异常
 *
 * @author MiMiKnight victor2015yhm@gmail.com
 * @date 2024-03-17 22:42:34
 * @since 2024-03-17 10:39:49
 */
@Getter
public class KucaMethodArgumentValidationException extends RuntimeException {
    @Serial
    private static final long serialVersionUID = -1404195234238113609L;

    /**
     * 校验信息有效载荷
     */
    private final ValidationPayload payload;

    public KucaMethodArgumentValidationException(String message, ValidationPayload payload) {
        super(message);
        this.payload = payload;
    }

}
