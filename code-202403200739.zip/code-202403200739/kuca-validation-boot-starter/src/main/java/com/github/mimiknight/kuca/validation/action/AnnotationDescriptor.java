package com.github.mimiknight.kuca.validation.action;

import com.github.mimiknight.kuca.validation.exception.AnnotationAttributeNotExistException;
import org.springframework.util.Assert;

import java.io.Serial;
import java.io.Serializable;
import java.lang.annotation.Annotation;
import java.security.PrivilegedAction;
import java.util.Map;

/**
 * 注解描述类
 *
 * @author MiMiKnight victor2015yhm@gmail.com
 * @since 2023-09-24 23:24:50
 */
public class AnnotationDescriptor<A extends Annotation> implements Serializable {

    @Serial
    private static final long serialVersionUID = 5051658628493775642L;

    /**
     * 注解类型
     */
    private final Class<? extends Annotation> type;

    /**
     * 注解
     */
    private final transient A annotation;

    /**
     * 注解属性集合
     */
    private final transient Map<String, Object> attributes;

    public AnnotationDescriptor(A annotation) {
        this.type = annotation.annotationType();
        this.annotation = annotation;
        this.attributes = run(GetAnnotationAttributes.action(annotation));
    }

    public AnnotationDescriptor(AnnotationDescriptor<A> descriptor) {
        this.type = descriptor.type;
        this.annotation = descriptor.annotation;
        this.attributes = descriptor.attributes;
    }

    /**
     * 获取注解类型
     *
     * @return {@link Class}<{@link ?} {@link extends} {@link Annotation}>
     */
    public Class<? extends Annotation> getType() {
        return type;
    }

    /**
     * 获取注解属性集合
     *
     * @return {@link Map}<{@link String}, {@link Object}>
     */
    public Map<String, Object> getAttributes() {
        return attributes;
    }

    /**
     * 获取注解
     *
     * @return {@link A}
     */
    public A getAnnotation() {
        return annotation;
    }

    /**
     * 是否包含指定名称的注解属性
     *
     * @param attributeName 属性名称
     * @return boolean
     */
    public boolean hasAttribute(String attributeName) {
        return attributes.containsKey(attributeName);
    }


    /**
     * 获取注解的属性
     *
     * @param attributeName 属性名称
     * @param attributeType 属性类型
     * @return {@link T}
     */
    public <T> T getAttribute(String attributeName, Class<T> attributeType) {
        Object attribute = attributes.get(attributeName);
        if (null == attribute) {
            return null;
        }
        if (!attributeType.isAssignableFrom(attribute.getClass())) {
            String format = "Wrong type for attribute '%2$s' of annotation %1$s. Expected: %3$s. Actual: %4$s.";
            String message = String.format(format, type, attributeName, attributeType, attribute.getClass());
            throw new IllegalArgumentException(message);
        }
        return attributeType.cast(attribute);
    }

    /**
     * 获取注解的必需属性
     *
     * @param attributeName 属性名称
     * @param attributeType 属性类型
     * @return {@link T}
     */
    public <T> T getMandatoryAttribute(String attributeName, Class<T> attributeType) {
        T attribute = getAttribute(attributeName, attributeType);
        if (null == attribute) {
            String format = "The specified annotation %1$s defines no attribute '%2$s'.";
            String message = String.format(format, type, attributeName);
            throw new AnnotationAttributeNotExistException(message);
        }
        return attribute;
    }

    private static <V> V run(PrivilegedAction<V> action) {
        return action.run();
    }

    public static class Builder<A extends Annotation> {
        private A annotation;

        public Builder<A> setAnnotation(A annotation) {
            Assert.notNull(annotation, "Parameter annotation should not be null.");
            this.annotation = annotation;
            return this;
        }

        public AnnotationDescriptor<A> build() {
            return new AnnotationDescriptor<>(annotation);
        }

    }
}
