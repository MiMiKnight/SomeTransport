package com.github.mimiknight.kuca.validation.exception;

/**
 * 注释属性不存在异常
 *
 * @author MiMiKnight victor2015yhm@gmail.com
 * @since 2024-03-19 19:37:18
 */
public class AnnotationAttributeNotExistException extends RuntimeException {

    private static final long serialVersionUID = -3664684893897729208L;

    public AnnotationAttributeNotExistException(String message) {
        super(message);
    }

    public AnnotationAttributeNotExistException() {
        super();
    }

    public AnnotationAttributeNotExistException(String message, Throwable cause) {
        super(message, cause);
    }

    public AnnotationAttributeNotExistException(Throwable cause) {
        super(cause);
    }
}
