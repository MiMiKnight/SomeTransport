package com.github.mimiknight.kuca.validation.action;

import com.github.mimiknight.kuca.validation.annotation.KucaConstraint;
import com.github.mimiknight.kuca.validation.annotation.KucaValidated;
import com.github.mimiknight.kuca.validation.annotation.KucaIgnoreValidation;
import com.github.mimiknight.kuca.validation.exception.KucaValidationException;
import com.github.mimiknight.kuca.validation.validator.ConstraintValidator;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.util.Assert;
import org.springframework.util.ReflectionUtils;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

/**
 * 约束帮助类
 *
 * @author MiMiKnight victor2015yhm@gmail.com
 * @since 2023-09-28 00:43:27
 */
public final class ConstraintHelper {

    private ConstraintHelper() {
    }

    public static final String VALIDATION_MESSAGES_RESOURCE_NAME = "ValidationMessages";

    /**
     * 获取目标对象的全部成员属性字段
     * <p>
     * 包括全部父类的继承属性
     *
     * @param target 目标对象
     * @return {@link List}<{@link Field}>
     */
    public static List<Field> getFields(Object target) {
        Assert.notNull(target, "Parameter must not be null.");
        Class<?> clazz = target.getClass();
        List<Field> fields = new LinkedList<>();
        while (null != clazz) {
            Field[] declaredFields = clazz.getDeclaredFields();
            List<Field> list = Arrays.stream(declaredFields).toList();
            fields.addAll(list);
            clazz = clazz.getSuperclass();
        }
        return fields;
    }

    /**
     * 是否为约束注解
     *
     * @param annotation 注解
     * @return boolean
     */
    public static <A extends Annotation> boolean isConstraintAnnotation(A annotation) {
        if (null == annotation) {
            return false;
        }
        Class<? extends Annotation> type = annotation.annotationType();
        // 目标不是注解类型，则非校验注解
        if (!type.isAnnotation()) {
            return false;
        }
        // 目标没有被指定注解修饰，则非校验注解
        if (!type.isAnnotationPresent(KucaConstraint.class)) {
            return false;
        }
        // 如果为校验注解，则Validator不允许为空
        KucaConstraint constraint = type.getDeclaredAnnotation(KucaConstraint.class);
        Class<? extends ConstraintValidator<?, ?>>[] validatorDataTypeArray = constraint.validatedBy();
        if (ArrayUtils.isEmpty(validatorDataTypeArray)) {
            return false;
        }

        ConstraintAnnotationDescriptor<A> descriptor = new ConstraintAnnotationDescriptor
                .Builder<A>().setAnnotation(annotation).build();

        // 目标注解属性为空，则非校验注解
        Map<String, Object> attributes = descriptor.getAttributes();
        if (MapUtils.isEmpty(attributes)) {
            return false;
        }
        // 目标注解指定属性不存在，则非校验注解
        return descriptor.hasAttribute(ConstraintAnnotationDescriptor.ERROR_CODE)
                && descriptor.hasAttribute(ConstraintAnnotationDescriptor.MESSAGE)
                && descriptor.hasAttribute(ConstraintAnnotationDescriptor.GROUPS);
    }

    /**
     * 获取约束注解
     *
     * @param annotations 注解数组
     * @return {@link List}<{@link Annotation}>
     */
    public static List<Annotation> getConstraintAnnotation(Annotation[] annotations) {
        if (ArrayUtils.isEmpty(annotations)) {
            return new ArrayList<>();
        }
        ArrayList<Annotation> list = new ArrayList<>();
        for (Annotation annotation : annotations) {
            if (isConstraintAnnotation(annotation)) {
                list.add(annotation);
            }
        }
        return list;
    }

    /**
     * 获取字段的约束注解
     *
     * @param field 字段
     * @return {@link List}<{@link Annotation}>
     */
    public static List<Annotation> getConstraintAnnotation(Field field) {
        Annotation[] annotations = field.getDeclaredAnnotations();
        return getConstraintAnnotation(annotations);
    }


    /**
     * 获取约束注解的校验器
     *
     * @param annotation 注解
     * @return {@link List}<{@link ConstraintValidator}<{@link Annotation}, {@link Object}>>
     */
    @SuppressWarnings({"unchecked"})
    public static List<ConstraintValidator<Annotation, Object>> getValidators(Annotation annotation) {
        if (!isConstraintAnnotation(annotation)) {
            return new ArrayList<>();
        }
        Class<? extends Annotation> type = annotation.annotationType();
        KucaConstraint constraint = type.getDeclaredAnnotation(KucaConstraint.class);
        Class<? extends ConstraintValidator<?, ?>>[] validatorDataTypeArray = constraint.validatedBy();

        return Arrays.stream(validatorDataTypeArray).map(dataType -> {
            try {
                ConstraintValidator<Annotation, Object> validator = (ConstraintValidator<Annotation, Object>) dataType.getDeclaredConstructor().newInstance();
                // 校验器数据初始化
                validator.initialize(annotation);
                return validator;
            } catch (InstantiationException | IllegalAccessException | InvocationTargetException |
                     NoSuchMethodException ex) {
                String format = "%s create instance failed.";
                String tip = String.format(format, dataType.getName());
                throw new KucaValidationException(tip, ex);
            }
        }).toList();

    }

    /**
     * 获取反射字段值
     *
     * @param target 目标
     * @param field  字段
     * @return {@link Object}
     */
    public static <T> Object getFieldValue(T target, Field field) {
        try {
            if (!field.canAccess(target)) {
                ReflectionUtils.makeAccessible(field);
            }
            return field.get(target);
        } catch (SecurityException | IllegalAccessException e) {
            throw new KucaValidationException("Get field value failed.", e);
        }
    }

    /**
     * 字段是否被{@link KucaValidated}注解装饰
     *
     * @param field 字段
     * @return boolean
     */
    public static boolean decorateByKucaValidated(Field field) {
        KucaValidated validated = field.getAnnotation(KucaValidated.class);
        return null != validated;
    }

    /**
     * 字段是否被{@link KucaIgnoreValidation}注解装饰
     *
     * @param field 字段
     * @return boolean
     */
    public static boolean decorateByKucaIgnoreValidation(Field field) {
        KucaIgnoreValidation ignore = field.getAnnotation(KucaIgnoreValidation.class);
        return null != ignore;
    }

    /**
     * 获取资源包
     *
     * @param name   资源名称
     * @param locale 国际化
     * @return {@link ResourceBundle}
     */
    private static ResourceBundle getResourceBundle(String name, Locale locale) {
        ResourceBundle bundle = ResourceBundle.getBundle(name, locale);
        if (null == bundle) {
            bundle = ResourceBundle.getBundle(name);
        }
        return bundle;
    }

    /**
     * 获取校验约束注解的校验提示消息
     *
     * @param descriptor 校验注解描述符
     * @return {@link String}
     */
    public static String getValidationMessage(ConstraintAnnotationDescriptor<Annotation> descriptor) {
        ResourceBundle bundle = getResourceBundle(VALIDATION_MESSAGES_RESOURCE_NAME, Locale.getDefault());
        String message = descriptor.getMessage();
        if (bundle.containsKey(message)) {
            message = bundle.getString(message);
        }
        return resolveMessage(message, descriptor);
    }

    /**
     * 解析消息
     *
     * @param message    消息
     * @param descriptor 注解描述符
     * @return {@link String}
     */
    private static String resolveMessage(String message, ConstraintAnnotationDescriptor<Annotation> descriptor) {
        Map<String, Object> attributes = descriptor.getAttributes();

        if (MapUtils.isEmpty(attributes)) {
            return message;
        }
        for (Map.Entry<String, Object> entries : attributes.entrySet()) {
            String key = entries.getKey();
            String value = entries.getValue().toString();
            key = "{" + key + "}";
            message = message.replace(key, value);
        }
        return message;
    }

}
