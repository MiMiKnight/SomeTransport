package com.github.mimiknight.kuca.validation.validator;

import com.github.mimiknight.kuca.validation.annotation.validation.KucaBlank;
import org.apache.commons.lang3.StringUtils;

/**
 * 空白字符串校验器
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-06-07 20:13:23
 */
public class BlankValidator implements ConstraintValidator<KucaBlank, Object> {

    @Override
    public boolean isValid(Object value) {
        if (null == value) {
            return true;
        }
        if (value instanceof String result) {
            return StringUtils.isBlank(result);
        }
        // 默认放通
        return true;
    }
}
