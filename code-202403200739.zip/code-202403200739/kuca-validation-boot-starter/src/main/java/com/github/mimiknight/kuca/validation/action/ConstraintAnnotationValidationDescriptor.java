package com.github.mimiknight.kuca.validation.action;

import com.github.mimiknight.kuca.validation.validator.ConstraintValidator;
import org.apache.commons.collections4.CollectionUtils;

import java.lang.annotation.Annotation;
import java.util.List;

/**
 * 约束注解校验描述类
 *
 * @author MiMiKnight victor2015yhm@gmail.com
 * @since 2024-03-19 19:16:22
 */
public class ConstraintAnnotationValidationDescriptor {

    /**
     * 注解
     */
    private final Annotation annotation;

    /**
     * 注解描述符
     */
    private final ConstraintAnnotationDescriptor<Annotation> annotationDescriptor;

    /**
     * 约束注解校验器
     */
    private final List<ConstraintValidator<Annotation, Object>> validators;

    private ConstraintAnnotationValidationDescriptor(Annotation annotation) {
        this.annotation = annotation;
        this.annotationDescriptor = new ConstraintAnnotationDescriptor.Builder<>().setAnnotation(annotation).build();
        this.validators = ConstraintHelper.getValidators(annotation);
    }

    /**
     * 创建校验描述符
     *
     * @param annotation 校验注解
     * @return {@link ConstraintAnnotationValidationDescriptor}<{@link V}, {@link A}>
     */
    public static ConstraintAnnotationValidationDescriptor create(Annotation annotation) {
        if (!ConstraintHelper.isConstraintAnnotation(annotation)) {
            throw new IllegalArgumentException("The type of parameter annotation is not constraint annotation");
        }
        return new ConstraintAnnotationValidationDescriptor(annotation);
    }

    /**
     * 获取注解
     *
     * @return {@link Annotation}
     */
    public Annotation getAnnotation() {
        return annotation;
    }

    /**
     * 获取注解描述符
     *
     * @return {@link ConstraintAnnotationDescriptor}<{@link Annotation}>
     */
    public ConstraintAnnotationDescriptor<Annotation> getAnnotationDescriptor() {
        return annotationDescriptor;
    }

    /**
     * 获取注解校验器
     *
     * @return {@link List}<{@link ConstraintValidator}<{@link Annotation}, {@link Object}>>
     */
    public List<ConstraintValidator<Annotation, Object>> getValidators() {
        return validators;
    }

    /**
     * 校验
     *
     * @param value 被校验的值
     * @return boolean
     */
    public boolean valid(Object value) {
        if (CollectionUtils.isEmpty(validators)) {
            return true;
        }
        for (ConstraintValidator<Annotation, Object> validator : validators) {
            validator.initialize(annotation);
            if (!validator.isValid(value)) {
                return false;
            }
        }
        return true;
    }

    /**
     * 获取错误码
     *
     * @return {@link String}
     */
    public String getErrorCode() {
        return this.annotationDescriptor.getErrorCode();
    }

    /**
     * 获取校验消息
     *
     * @return {@link String}
     */
    public String getMessage() {
        return ConstraintHelper.getValidationMessage(this.annotationDescriptor);
    }

}
