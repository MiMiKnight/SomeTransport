package com.github.mimiknight.kuca.validation.action;

import java.io.Serial;
import java.lang.annotation.Annotation;

/**
 * 约束注解描述类
 *
 * @author MiMiKnight victor2015yhm@gmail.com
 * @since 2023-09-24 23:50:20
 */
public final class ConstraintAnnotationDescriptor<A extends Annotation> extends AnnotationDescriptor<A> {

    @Serial
    private static final long serialVersionUID = -690092475442072888L;
    public static final String MESSAGE = "message";
    public static final String ERROR_CODE = "errorCode";
    public static final String GROUPS = "groups";

    private ConstraintAnnotationDescriptor(A annotation) {
        super(annotation);
    }

    private ConstraintAnnotationDescriptor(AnnotationDescriptor<A> descriptor) {
        super(descriptor);
    }

    /**
     * 获取错误码属性
     *
     * @return {@link String}
     */
    public String getErrorCode() {
        return getMandatoryAttribute(ERROR_CODE, String.class);
    }

    /**
     * 获取消息属性
     *
     * @return {@link String}
     */
    public String getMessage() {
        return getMandatoryAttribute(MESSAGE, String.class);
    }

    /**
     * 获取校验分组属性
     *
     * @return {@link Class}<{@link ?}>{@link []}
     */
    public Class<?>[] getGroups() {
        return getMandatoryAttribute(GROUPS, Class[].class);
    }

    public static class Builder<A extends Annotation> extends AnnotationDescriptor.Builder<A> {

        @Override
        public Builder<A> setAnnotation(A annotation) {
            super.setAnnotation(annotation);
            return this;
        }

        @Override
        public ConstraintAnnotationDescriptor<A> build() {
            return new ConstraintAnnotationDescriptor<>(super.build());
        }
    }

}
