package com.github.mimiknight.kuca.validation.validator;

import java.lang.annotation.Annotation;

/**
 * 约束注解校验器接口
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-06-07 20:10:52
 */
public interface ConstraintValidator<A extends Annotation, V> {

    /**
     * 初始化
     *
     * @param constraintAnnotation 约束注解
     */
    default void initialize(A constraintAnnotation) {
    }

    /**
     * 是否校验通过
     * <p>
     * 校验通过：true；未校验通过：false
     *
     * @param value 被校验值
     * @return boolean
     */
    boolean isValid(V value);
}
