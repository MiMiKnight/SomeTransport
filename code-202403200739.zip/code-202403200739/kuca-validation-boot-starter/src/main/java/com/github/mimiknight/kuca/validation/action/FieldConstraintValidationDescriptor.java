package com.github.mimiknight.kuca.validation.action;

import java.lang.reflect.Field;
import java.util.List;

/**
 * 字段约束验证描述符
 *
 * @author MiMiKnight victor2015yhm@gmail.com
 * @since 2024-03-19 20:27:19
 */
public class FieldConstraintValidationDescriptor {

    /**
     * 被校验的反射字段
     */
    private final Field field;

    /**
     * 校验分组
     */
    private final Class<?>[] groups;

    private final List<ConstraintAnnotationValidationDescriptor> cavds;

    private FieldConstraintValidationDescriptor(Field field, Class<?>[] groups) {
        this.field = field;
        this.groups = groups;
        this.cavds = null;
    }

    public static FieldConstraintValidationDescriptor create(Field field, Class<?>[] groups) {
        return new FieldConstraintValidationDescriptor(field, groups);
    }

    public Field getField() {
        return field;
    }

    public Class<?>[] getGroups() {
        return groups;
    }
}
