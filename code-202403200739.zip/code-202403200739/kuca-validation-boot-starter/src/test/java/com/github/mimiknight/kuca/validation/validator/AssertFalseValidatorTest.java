package com.github.mimiknight.kuca.validation.validator;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = {AssertFalseValidator.class})
class AssertFalseValidatorTest {

    @Spy
    private AssertFalseValidator validator;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void isValid01() {
        validator.initialize(null);
        Assertions.assertTrue(validator.isValid(Boolean.FALSE));
        Assertions.assertFalse(validator.isValid(Boolean.TRUE));

        Mockito.verify(validator, Mockito.atLeastOnce()).isValid(Mockito.any());
        Mockito.verify(validator, Mockito.times(1)).initialize(Mockito.any());
    }
}