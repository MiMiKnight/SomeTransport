# kuca-validation-boot-starter

## Project Version
- 1.0.0-SNAPSHOT
### requirement
- OracleJDK v17.0.8
- maven 3.9.0-3.9.6
### dependency version
- spring-boot v3.0.9