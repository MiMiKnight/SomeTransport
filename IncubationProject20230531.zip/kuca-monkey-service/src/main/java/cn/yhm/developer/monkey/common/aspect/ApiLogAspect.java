package cn.yhm.developer.monkey.common.aspect;


import cn.yhm.developer.kuca.common.utils.standard.JsonService;
import cn.yhm.developer.monkey.common.constant.AspectRule;
import cn.yhm.developer.monkey.common.util.PrintApiLogUtils;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.LocalDateTime;

/**
 * 请求接口日志切面
 * <p>
 * spring 5.3.23
 * <p>
 * 异常情况：
 * 1.Around-start => 2.Before => 3.目标方法执行 => 4.AfterThrowing => 5.After
 * 正常情况：
 * 1.Around-start => 2.Before => 3.目标方法执行 => 4.AfterReturning => 5.After=> 6.Around-end
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-02 14:18:33
 */
@Slf4j
@Component
@Aspect
public class ApiLogAspect implements Ordered {

    private JsonService jsonService;

    private PrintApiLogUtils printApiLogUtils;

    @Autowired
    public void setPrintApiLogUtils(PrintApiLogUtils printApiLogUtils) {
        this.printApiLogUtils = printApiLogUtils;
    }

    @Autowired
    public void setJsonService(JsonService jsonService) {
        this.jsonService = jsonService;
    }

    /**
     * 切入点
     */
    @Pointcut(AspectRule.Rule001.RULE_PATTERN)
    public void pointcut() {
    }

    /**
     * 环绕通知
     * <p>
     * 接口入参日志
     */
    @Around(value = "pointcut()")
    public Object doAround(ProceedingJoinPoint point) throws Throwable {
        // 接口耗时 开始时间
        ThreadLocal<LocalDateTime> timeThreadLocal = new ThreadLocal<>();
        timeThreadLocal.set(LocalDateTime.now());
        Signature signature = point.getSignature();
        Object[] args = point.getArgs();
        // 打印请求参数日志
        // 执行被切业务逻辑
        return point.proceed();
    }

    @AfterReturning(value = "pointcut()", returning = "returning")
    public void doAfterReturning(Object returning) throws IOException {
        String responseJson = jsonService.toJson(returning);
        printApiLogUtils.traceResponse(responseJson);
    }

    @Override
    public int getOrder() {
        return AspectRule.Rule001.Order.ORDER_002;
    }
}
