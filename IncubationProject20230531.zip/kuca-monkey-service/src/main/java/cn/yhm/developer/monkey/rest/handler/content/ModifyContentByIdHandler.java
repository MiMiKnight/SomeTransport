package cn.yhm.developer.monkey.rest.handler.content;

import cn.yhm.developer.kuca.ecology.core.EcologyRequestHandler;
import cn.yhm.developer.monkey.model.entity.ContentEntity;
import cn.yhm.developer.monkey.model.request.ModifyContentByIdRequest;
import cn.yhm.developer.monkey.model.response.ModifyContentByIdResponse;
import cn.yhm.developer.monkey.service.standard.ContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 保存内容处理器类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-09 20:32:18
 */
@Component
public class ModifyContentByIdHandler implements EcologyRequestHandler<ModifyContentByIdRequest, ModifyContentByIdResponse> {

    @Autowired
    private ContentService contentService;

    @Override
    public void handle(ModifyContentByIdRequest request, ModifyContentByIdResponse response) throws Exception {
        String id = request.getId();
        String content = request.getContent();
        ContentEntity entity = contentService.getById(id);
        entity.setContent(content);
        contentService.updateById(entity);
    }
}
