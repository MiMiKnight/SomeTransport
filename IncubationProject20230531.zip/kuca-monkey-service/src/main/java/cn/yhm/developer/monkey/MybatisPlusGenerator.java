package cn.yhm.developer.monkey;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.config.DataSourceConfig;
import com.baomidou.mybatisplus.generator.config.GlobalConfig;
import com.baomidou.mybatisplus.generator.config.InjectionConfig;
import com.baomidou.mybatisplus.generator.config.OutputFile;
import com.baomidou.mybatisplus.generator.config.PackageConfig;
import com.baomidou.mybatisplus.generator.config.StrategyConfig;
import com.baomidou.mybatisplus.generator.config.TemplateConfig;
import com.baomidou.mybatisplus.generator.config.TemplateType;
import com.baomidou.mybatisplus.generator.config.converts.MySqlTypeConvert;
import com.baomidou.mybatisplus.generator.config.po.LikeTable;
import com.baomidou.mybatisplus.generator.config.querys.MariadbQuery;
import com.baomidou.mybatisplus.generator.config.rules.DateType;
import com.baomidou.mybatisplus.generator.config.rules.NamingStrategy;
import com.baomidou.mybatisplus.generator.fill.Column;
import com.baomidou.mybatisplus.generator.fill.Property;
import com.baomidou.mybatisplus.generator.keywords.MySqlKeyWordsHandler;

import java.util.Collections;
import java.util.function.Consumer;

/**
 * MybatisPlus 代码生成器
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-22 07:25:08
 */
public class MybatisPlusGenerator {

    public static void main(String[] args) {
        generate();
    }

    public static void generate() {
        FastAutoGenerator.create(buildDataSourceConfig())
                .globalConfig(BUILD_GLOBAL_CONFIG)
                .packageConfig(BUILD_PACKAGE_CONFIG)
//                .templateConfig(BUILD_TEMPLATE_CONFIG)
//                .injectionConfig(BUILD_INJECTION_CONFIG)
                .strategyConfig(BUILD_STRATEGY_CONFIG)
                .execute();
    }

    /**
     * 数据库配置
     *
     * @return {@link DataSourceConfig}
     */
    private static DataSourceConfig.Builder buildDataSourceConfig() {
        String url = "jdbc:mariadb://127.0.0.1:3306/db_monkey?useUnicode=true&characterEncoding=utf8mb4&serverTimezone=Asia/Shanghai&useSSL=false&allowMultiQueries=true";
        String username = "root";
        String password = "123456";
        String schema = "db_monkey";
        return new DataSourceConfig.Builder(url, username, password)
                .dbQuery(new MariadbQuery())
                .schema(schema)
                .typeConvert(new MySqlTypeConvert())
                .keyWordsHandler(new MySqlKeyWordsHandler());
    }


    /**
     * 全局配置
     */
    private static final Consumer<GlobalConfig.Builder> BUILD_GLOBAL_CONFIG = (builder) -> {
        String outputDir = "./generate";
        String author = "victor2015yhm@gmail.com";
        String commentDateFormat = "yyyy-MM-dd HH:mm:dd";
        builder.outputDir(outputDir)
                .author(author)
                .enableKotlin()
                .enableSwagger()
                .dateType(DateType.TIME_PACK)
                .commentDate(commentDateFormat);
    };


    /**
     * 包配置
     */
    private static final Consumer<PackageConfig.Builder> BUILD_PACKAGE_CONFIG = (builder) -> {
        String parent = "cn.yhm.developer.monkey.generate";
        String moduleName = "monkey";
        String entityPackageName = "entity";
        String servicePackageName = "service";
        String serviceImplPackageName = "service.impl";
        String mapperPackageName = "mapper";
        String mapperXmlPackageName = "mapper.xml";
        String controllerPackageName = "controller";
        String otherPackageName = "other";
        String xmlOutputDir = "D://";
        builder.parent(parent)
                .moduleName(moduleName)
                .entity(entityPackageName)
                .service(servicePackageName)
                .serviceImpl(serviceImplPackageName)
                .mapper(mapperPackageName)
                .xml(mapperXmlPackageName)
                .controller(controllerPackageName)
                .other(otherPackageName)
                .pathInfo(Collections.singletonMap(OutputFile.xml, xmlOutputDir));
    };

    /**
     * 模板配置
     */
    private static final Consumer<TemplateConfig.Builder> BUILD_TEMPLATE_CONFIG = (builder) -> {
        builder.disable(TemplateType.ENTITY)
                .entity("/templates/entity.java")
                .service("/templates/service.java")
                .serviceImpl("/templates/serviceImpl.java")
                .mapper("/templates/mapper.java")
                .xml("/templates/mapper.xml")
                .controller("/templates/controller.java")
                .build();
    };

    /**
     * 注入配置
     */
    private static final Consumer<InjectionConfig.Builder> BUILD_INJECTION_CONFIG = (builder) -> {
        builder.beforeOutputFile((tableInfo, objectMap) -> {
                    System.out.println("tableInfo: " + tableInfo.getEntityName() + " objectMap: " + objectMap.size());
                })
                .customMap(Collections.singletonMap("test", "baomidou"))
                .customFile(Collections.singletonMap("test.txt", "/templates/test.vm"))
                .build();
    };

    /**
     * 策略配置
     * <p>
     * Entity 策略配置
     * <p>
     * Mapper 策略配置
     * <p>
     * Service 策略配置
     * <p>
     * Controller 策略配置
     */
    private static final Consumer<StrategyConfig.Builder> BUILD_STRATEGY_CONFIG = (builder) -> {
        builder.enableCapitalMode()
                .enableSkipView()
                .disableSqlFilter()
                .likeTable(new LikeTable("USER"))
                .addInclude("t_simple")
                .addTablePrefix("t_monkey")
                .addFieldSuffix("_flag")
                // 构建Entity
                .entityBuilder()
                .disableSerialVersionUID()
                .enableChainModel()
                .enableLombok()
                .enableRemoveIsPrefix()
                .enableTableFieldAnnotation()
                .enableActiveRecord()
                .versionColumnName("version")
                .versionPropertyName("version")
                .logicDeleteColumnName("deleted")
                .logicDeletePropertyName("deleteFlag")
                .naming(NamingStrategy.no_change)
                .columnNaming(NamingStrategy.underline_to_camel)
                .addSuperEntityColumns("id", "created_by", "created_time", "updated_by", "updated_time")
                .addIgnoreColumns("age")
                .addTableFills(new Column("create_time", FieldFill.INSERT))
                .addTableFills(new Property("updateTime", FieldFill.INSERT_UPDATE))
                .idType(IdType.ASSIGN_ID)
                .formatFileName("%sEntity")
                // 构建 Mapper
                .mapperBuilder()
                .superClass(BaseMapper.class)
                .enableMapperAnnotation()
                .enableBaseResultMap()
                .enableBaseColumnList()
                .formatMapperFileName("%sMapper")
                .formatXmlFileName("%sMapperXml")
                // 构建 Service
                .serviceBuilder()
                .formatServiceFileName("%sService")
                .formatServiceImplFileName("%sServiceImpl")
                // 构建 Controller
                .controllerBuilder()
                .enableHyphenStyle()
                .enableRestStyle()
                .formatFileName("%sController")
                .build();
    };


}
