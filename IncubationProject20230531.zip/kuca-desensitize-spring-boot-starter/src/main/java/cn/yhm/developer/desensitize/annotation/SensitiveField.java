package cn.yhm.developer.desensitize.annotation;

import cn.yhm.developer.desensitize.strategy.SensitiveStrategy;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 敏感字段注解
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-22 02:19:57
 */
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface SensitiveField {

    /**
     * 脱敏策略
     *
     * @return {@link Class}<{@link ?}>
     */
    Class<? extends SensitiveStrategy> strategy();
}
