package cn.yhm.developer.desensitize.enumeration;

/**
 * 敏感类型接口
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-22 02:41:55
 */
public interface SensitiveType {

}
