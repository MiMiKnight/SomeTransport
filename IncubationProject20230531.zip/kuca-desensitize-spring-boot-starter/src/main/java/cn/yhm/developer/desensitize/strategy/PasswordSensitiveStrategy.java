package cn.yhm.developer.desensitize.strategy;

/**
 * 密码敏感策略
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-22 02:16:44
 */
public class PasswordSensitiveStrategy implements SensitiveStrategy {

    @Override
    public String desensitize(String text) {
        return null;
    }
}
