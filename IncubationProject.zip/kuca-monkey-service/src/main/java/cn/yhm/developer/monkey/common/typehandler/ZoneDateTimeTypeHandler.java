package cn.yhm.developer.monkey.common.typehandler;

import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;
import org.apache.ibatis.type.MappedJdbcTypes;
import org.apache.ibatis.type.MappedTypes;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.ZonedDateTime;

/**
 * 日期类型处理程序
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-25 23:04:56
 */
@MappedJdbcTypes(JdbcType.DATETIMEOFFSET)
@MappedTypes(ZonedDateTime.class)
public class ZoneDateTimeTypeHandler extends BaseTypeHandler<ZonedDateTime> {

    @Override
    public void setNonNullParameter(PreparedStatement preparedStatement, int i, ZonedDateTime dateTime, JdbcType jdbcType) throws SQLException {
        Instant instant = ZonedDateTime.now().toInstant();
        Timestamp timestamp = Timestamp.from(instant);
        preparedStatement.setTimestamp(i, timestamp);
    }

    @Override
    public ZonedDateTime getNullableResult(ResultSet resultSet, String s) throws SQLException {
        Timestamp timestamp = resultSet.getTimestamp(s);
        Instant instant = timestamp.toInstant();
        return ZonedDateTime.from(instant);
    }

    @Override
    public ZonedDateTime getNullableResult(ResultSet resultSet, int i) throws SQLException {
        Timestamp timestamp = resultSet.getTimestamp(i);
        Instant instant = timestamp.toInstant();
        return ZonedDateTime.from(instant);
    }

    @Override
    public ZonedDateTime getNullableResult(CallableStatement callableStatement, int i) throws SQLException {
        Timestamp timestamp = callableStatement.getTimestamp(i);
        Instant instant = timestamp.toInstant();
        return ZonedDateTime.from(instant);
    }
}
