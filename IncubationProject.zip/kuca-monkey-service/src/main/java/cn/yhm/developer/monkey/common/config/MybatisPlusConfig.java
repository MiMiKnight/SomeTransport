package cn.yhm.developer.monkey.common.config;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.BlockAttackInnerInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.OptimisticLockerInnerInterceptor;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.ZonedDateTime;
import java.util.Date;

/**
 * MybatisPlus配置类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-22 07:51:51
 */
@Configuration
public class MybatisPlusConfig {

    @Bean
    public MetaObjectHandler myMetaObjectHandler() {
        return new MetaObjectHandler() {

            @Override
            public void insertFill(MetaObject metaObject) {
                Date date = new Date();
                ZonedDateTime now = ZonedDateTime.now();
                // 自动插入 创建时间
//                this.strictInsertFill(metaObject, "createTime", now, ZonedDateTime.class);
                this.strictInsertFill(metaObject, "createTime", () -> date, Date.class);
                // 自动插入 更新时间
//                this.strictInsertFill(metaObject, "updateTime", now, ZonedDateTime.class);
                this.strictInsertFill(metaObject, "updateTime", () -> date, Date.class);
            }

            @Override
            public void updateFill(MetaObject metaObject) {
                Date date = new Date();
                // 自动更新插入 更新时间
//                this.strictUpdateFill(metaObject, "updateTime", ZonedDateTime::now, ZonedDateTime.class);
                this.strictUpdateFill(metaObject, "updateTime", () -> date, Date.class);
            }
        };
    }


    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        // 乐观锁插件
        interceptor.addInnerInterceptor(new OptimisticLockerInnerInterceptor());
        // 防全表更新与删除插件
        interceptor.addInnerInterceptor(new BlockAttackInnerInterceptor());
        return interceptor;
    }
}
