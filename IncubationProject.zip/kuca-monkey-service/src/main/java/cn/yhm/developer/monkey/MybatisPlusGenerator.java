package cn.yhm.developer.monkey;

/**
 * MybatisPlus 代码生成器
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-22 07:25:08
 */
public class MybatisPlusGenerator {

    public static void main(String[] args) {

    }

    public static void generate() {

    }
}
