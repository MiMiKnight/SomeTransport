package cn.yhm.developer.monkey.common.constant;

/**
 * 切面规则定义类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-02 15:24:30
 */
public interface AspectRule {

    /**
     * 001切面规则
     */
    interface Rule001 {

        /**
         * 切面规则
         */
        String RULE_PATTERN = "@within(org.springframework.web.bind.annotation.RestController) || @within(org.springframework.stereotype.Controller)";

        /**
         * 切面顺序
         */
        interface Order {
            int ORDER_001 = 500;
            int ORDER_002 = 501;
        }
    }

    /**
     * 002切面规则
     */
    interface Rule002 {
        String RULE_PATTERN = "execution(public cn.yhm.developer.kuca.ecology.model.response.ExceptionResponse " +
                "cn.yhm.developer.kuca.monkey.common.aspect.HandleExceptionAspect.handle(..))";

        interface Order {
            int ORDER_001 = 500;
        }
    }
}
