package cn.yhm.developer.monkey.service.impl;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Slf4j
@SpringBootTest
public class ContentServiceTest {

    @Test
    public void test01() {
        log.info("小白开始付款");
        CompletableFuture<String> future = CompletableFuture.supplyAsync(() -> {
            log.info("服务员收款500元");
            return "500";
        }).thenApplyAsync(money -> {
            log.info("服务员开{}元发票", money);
            return money + "元发票";
        });
        log.info("小白在等待开发票的同时在接电话");
        log.info("小白接完电话，拿{}回家", future.join());
    }

    @Test
    public void test02() {
        List<CompletableFuture<String>> futureList = IntStream.range(1, 10).mapToObj(i ->
                CompletableFuture.supplyAsync(() ->
                        i + "-hello"
                )
        ).collect(Collectors.toList());
        CompletableFuture.allOf(futureList.toArray(new CompletableFuture[]{}));
        
    }

}