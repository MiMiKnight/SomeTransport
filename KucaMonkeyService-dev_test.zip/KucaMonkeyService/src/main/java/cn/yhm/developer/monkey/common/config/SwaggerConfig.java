package cn.yhm.developer.monkey.common.config;

import org.springframework.context.annotation.Configuration;

/**
 * Swagger配置类
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-02 19:47:28
 */
@Configuration
public class SwaggerConfig {
}
