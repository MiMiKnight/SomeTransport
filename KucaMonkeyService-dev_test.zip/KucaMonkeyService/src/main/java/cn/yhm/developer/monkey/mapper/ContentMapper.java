package cn.yhm.developer.monkey.mapper;

import cn.yhm.developer.monkey.model.entity.ContentEntity;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Content模块Mapper
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 13:59:24
 */
@Mapper
@Repository
public interface ContentMapper {

    /**
     * 保存一条记录
     *
     * @param entity 实体类
     * @return {@link Long}
     */
    Integer save(@Param("entity") ContentEntity entity);

    /**
     * 根据主键物理删除
     *
     * @param key 主键
     * @return {@link Long}
     */
    Integer removeByPrimaryKey(@Param("key") Long key);

    /**
     * 根据主键逻辑删除
     *
     * @param key        主键
     * @param updateTime 更新时间
     * @param version    乐观锁版本号
     * @return {@link Long}
     */
    Integer deleteByPrimaryKey(@Param("key") Long key, @Param("version") Integer version, @Param("updateTime") LocalDateTime updateTime);

    /**
     * 根据主键获取内容表的记录
     *
     * @param key 主键
     * @return {@link ContentEntity}
     */
    ContentEntity selectContentByPrimaryKey(@Param("key") Long key);

    /**
     * 根据主键集合查询记录
     *
     * @param idList 主键集合
     * @return {@link List}<{@link ContentEntity}>
     */
    List<ContentEntity> selectContentByIdList(@Param("idList") List<Long> idList);

    /**
     * 通过主键更新实体类
     *
     * @param entity 实体类
     * @return {@link Integer}
     */
    Integer updateByPrimaryKey(@Param("entity") ContentEntity entity);
}
