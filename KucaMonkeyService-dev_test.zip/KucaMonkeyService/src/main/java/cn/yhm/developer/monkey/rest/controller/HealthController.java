package cn.yhm.developer.monkey.rest.controller;

import cn.yhm.developer.kuca.ecology.rest.controller.AbstractEcologyHandlerAdapter;
import cn.yhm.developer.monkey.model.request.HealthCheckRequest;
import cn.yhm.developer.monkey.model.response.HealthCheckResponse;
import cn.yhm.developer.monkey.rest.handler.HealthCheckHandler;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 健康检查前端控制器
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-02 20:18:30
 */
@RestController
@RequestMapping(value = {Controller.Health.MODULE_VISIT_PREFIX}, produces = {MediaType.APPLICATION_JSON_VALUE})
public class HealthController extends AbstractEcologyHandlerAdapter implements Controller.Health {

    @GetMapping(value = {"/check"})
    @Override
    public HealthCheckResponse healthCheck(HealthCheckRequest request) throws Exception {
        return handle(request, HealthCheckHandler.class);
    }
}
