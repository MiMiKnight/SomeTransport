package cn.yhm.developer.monkey.rest.handler;

import cn.yhm.developer.kuca.common.constant.TimeZone;
import cn.yhm.developer.kuca.common.utils.DateUtils;
import cn.yhm.developer.kuca.ecology.rest.handler.EcologyHandleable;
import cn.yhm.developer.monkey.model.VO.response.GetContentByIdRespVO;
import cn.yhm.developer.monkey.model.entity.ContentEntity;
import cn.yhm.developer.monkey.model.request.GetContentByIdRequest;
import cn.yhm.developer.monkey.model.response.GetContentByIdResponse;
import cn.yhm.developer.monkey.service.ContentService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 20:02:33
 */
@Component
public class GetContentByIdHandler implements EcologyHandleable<GetContentByIdRequest, GetContentByIdResponse> {

    @Resource
    private ContentService contentService;

    @Override
    public GetContentByIdResponse handle(GetContentByIdRequest request) throws Exception {
        GetContentByIdResponse response = new GetContentByIdResponse();
        DateUtils dateUtils = new DateUtils();
        // 校验ID是否存在
        List<Long> idList = request.getIdList();
        List<ContentEntity> entityList = contentService.selectContentByIdList(idList);
        List<GetContentByIdRespVO> results = null;
        if (entityList != null) {
            results = entityList.stream().map(entity -> {
                GetContentByIdRespVO vo = new GetContentByIdRespVO();
                vo.setId(entity.getId());
                vo.setContent(entity.getContent());
                vo.setCreatTime(dateUtils.getZonedDateTime(entity.getCreateTime(), TimeZone.UTC.ZERO));
                vo.setUpdateTime(dateUtils.getZonedDateTime(entity.getUpdateTime(), TimeZone.UTC.ZERO));
                return vo;
            }).collect(Collectors.toList());
        }
        response.setResults(results);
        return response;
    }
}
