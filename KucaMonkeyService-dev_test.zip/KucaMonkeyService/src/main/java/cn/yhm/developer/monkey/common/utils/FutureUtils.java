package cn.yhm.developer.monkey.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * @author victor2015yhm@gmail.com
 * @since 2023-01-15 21:10:37
 */
@Slf4j
@Component
public class FutureUtils {

    @Resource
    private ThreadPoolTaskExecutor executor;

    private final ScheduledExecutorService scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();

    /**
     * 执行异步有返回值线程
     *
     * @param supplier     线程执行程序
     * @param timeoutValue 线程超时返回值
     * @param timeout      超时时间
     * @param unit         时间单位
     * @param fn           发生异常时传入的函数式接口
     * @return {@link CompletableFuture}<{@link T}>
     */
    public <T> CompletableFuture<T> supplyAsync(Supplier<T> supplier, Function<Throwable, ? extends T> fn, T timeoutValue, long timeout, TimeUnit unit) {
        return CompletableFuture.supplyAsync(supplier, executor).completeOnTimeout(timeoutValue, timeout, unit).exceptionally(fn);
    }

    /**
     * 执行异步有返回值线程
     *
     * @param supplier     线程执行程序
     * @param timeoutValue 线程超时返回值
     * @param timeout      超时时间
     * @param unit         时间单位
     * @param action       当线程执行完成或者发生异常时，执行的动作
     * @return {@link CompletableFuture}<{@link T}>
     */
    public <T> CompletableFuture<T> supplyAsync(Supplier<T> supplier, BiConsumer<? super T, ? super Throwable> action, T timeoutValue, long timeout, TimeUnit unit) {
        return CompletableFuture.supplyAsync(supplier, executor).completeOnTimeout(timeoutValue, timeout, unit).whenCompleteAsync(action, executor);
    }

    /**
     * 执行异步有返回值线程
     *
     * @param supplier 线程执行程序
     * @param timeout  超时时间
     * @param unit     时间单位
     * @param action   当线程执行完成或者发生异常时，执行的动作
     * @return {@link CompletableFuture}<{@link T}>
     */
    public <T> CompletableFuture<T> supplyAsync(Supplier<T> supplier, BiConsumer<? super T, ? super Throwable> action, long timeout, TimeUnit unit) {
        return CompletableFuture.supplyAsync(supplier, executor).applyToEitherAsync(CompletableFuture.supplyAsync(() -> {
            scheduledExecutorService.schedule(() -> log.info("run schedule task"), timeout, unit);
            return null;
        }), Function.identity(), executor).whenCompleteAsync(action, executor);
    }


    public CompletableFuture<Void> runAsync(Runnable runnable, BiConsumer<? super Void, ? super Throwable> action, long timeout, TimeUnit unit) {
        return CompletableFuture.runAsync(runnable, executor).completeOnTimeout(null, timeout, unit).whenCompleteAsync(action, executor);
    }
}
}
