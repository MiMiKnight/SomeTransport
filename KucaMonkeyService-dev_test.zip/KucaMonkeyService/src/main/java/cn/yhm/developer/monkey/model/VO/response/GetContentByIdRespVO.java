package cn.yhm.developer.monkey.model.VO.response;

import cn.yhm.developer.kuca.common.constant.DateTimePattern;
import cn.yhm.developer.kuca.common.constant.TimeZone;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.time.ZonedDateTime;

/**
 * GetContentByIdRespVO
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 20:06:57
 */
@Getter
@Setter
public class GetContentByIdRespVO {

    /**
     * 内容主键
     */
    @JsonProperty(value = "id", index = 1)
    private Long id;

    /**
     * 内容
     */
    @JsonProperty(value = "content", index = 2)
    private String content;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = DateTimePattern.STANDARD_03, timezone = TimeZone.GMT.EAST_8)
    @JsonProperty(value = "creat_time", index = 3)
    private ZonedDateTime creatTime;

    /**
     * 更新时间
     */
    @JsonFormat(pattern = DateTimePattern.STANDARD_03, timezone = TimeZone.GMT.EAST_8)
    @JsonProperty(value = "update_time", index = 4)
    private ZonedDateTime updateTime;

}
