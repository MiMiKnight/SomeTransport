package cn.yhm.developer.monkey.rest.handler;

import cn.yhm.developer.kuca.ecology.rest.handler.EcologyHandleable;
import cn.yhm.developer.monkey.model.request.SaveContentRequest;
import cn.yhm.developer.monkey.model.response.SaveContentResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 保持内容处理器
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 12:58:09
 */
@Slf4j
@Component
public class SaveContentHandler implements EcologyHandleable<SaveContentRequest, SaveContentResponse> {
    @Override
    public SaveContentResponse handle(SaveContentRequest request) throws Exception {
        log.info("SaveContentHandler...handle()...info");
        log.debug("SaveContentHandler...handle()...debug");
        List<String> contentList = request.getContentList();
        // TODO: 校验内容合法性(不能为非法字符、不能为空)

        return new SaveContentResponse();
    }
}
