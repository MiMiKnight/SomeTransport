package cn.yhm.developer.monkey.model.request;

import cn.yhm.developer.kuca.ecology.model.request.EcologyRequest;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * 保存内容响应参数
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 12:52:50
 */
@Setter
@Getter
public class SaveContentRequest implements EcologyRequest {

    /**
     * 内容
     * <p>
     * 内容条数限制 1-500
     */
    @NotNull(message = "The parameter can not be null")
    @Size(min = 1, max = 500, message = "The capacity of parameter out of range")
    @JsonProperty(value = "content_list")
    private List<String> contentList;
}
