package cn.yhm.developer.monkey.rest.handler;

import cn.yhm.developer.kuca.ecology.rest.handler.EcologyHandleable;
import cn.yhm.developer.monkey.common.constant.ProjectConstant;
import cn.yhm.developer.monkey.model.request.HealthCheckRequest;
import cn.yhm.developer.monkey.model.response.HealthCheckResponse;
import cn.yhm.developer.monkey.service.UploadDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 健康检查处理器
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 19:54:19
 */
@Slf4j
@Component
public class HealthCheckHandler implements EcologyHandleable<HealthCheckRequest, HealthCheckResponse> {

    @Resource
    private UploadDataService uploadDataService;

    @Resource
    private ThreadPoolTaskExecutor executor;

    @Override
    public HealthCheckResponse handle(HealthCheckRequest request) throws Exception {

        uploadDataService.getHello();
        HealthCheckResponse response = new HealthCheckResponse();
        response.setAppName("KucaMonkeyService");
        response.setStatus(ProjectConstant.AppStatus.UP);
        return response;
    }
}
