package cn.yhm.developer.monkey.model.response;

import cn.yhm.developer.kuca.ecology.model.response.AbstractResultsResponse;
import cn.yhm.developer.monkey.model.VO.response.GetContentByIdRespVO;
import lombok.Getter;
import lombok.Setter;

/**
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 19:59:44
 */
@Setter
@Getter
public class GetContentByIdResponse extends AbstractResultsResponse<GetContentByIdRespVO> {
}
