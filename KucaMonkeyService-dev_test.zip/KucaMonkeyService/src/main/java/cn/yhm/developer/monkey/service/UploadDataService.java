package cn.yhm.developer.monkey.service;

/**
 * 上传数据服务接口
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-01-14 23:57:53
 */
public interface UploadDataService {

    void getHello();
}
