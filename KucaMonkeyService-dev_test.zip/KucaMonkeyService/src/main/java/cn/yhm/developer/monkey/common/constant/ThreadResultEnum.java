package cn.yhm.developer.monkey.common.constant;

/**
 * 线程运行结果枚举类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-01-15 23:01:33
 */
public enum ThreadResultEnum {

    /**
     * 线程执行成功
     */
    SUCCESS,

    /**
     * 线程执行失败
     */
    FAILED;
}
