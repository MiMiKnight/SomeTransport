package cn.yhm.developer.monkey.common.config;

import org.springframework.context.annotation.Configuration;

/**
 * RestTemplate配置类
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-11 11:37:36
 */
@Configuration
public class RestTemplateConfiguration {
}
