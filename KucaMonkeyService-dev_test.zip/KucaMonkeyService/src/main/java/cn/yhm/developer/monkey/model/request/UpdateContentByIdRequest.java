package cn.yhm.developer.monkey.model.request;

import cn.yhm.developer.kuca.ecology.model.request.EcologyRequest;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 19:59:44
 */
@Setter
@Getter
public class UpdateContentByIdRequest implements EcologyRequest {

    /**
     * 主键
     * <p>
     * 限制一次性查询最多500条数据，最少查询1条数据
     */
    @NotNull(message = "The parameter can not be null")
    @JsonProperty(value = "id")
    private Long id;

    /**
     * 内容
     */
    @NotBlank(message = "The parameter can not be empty")
    @JsonProperty(value = "content")
    private String content;
}
