package cn.yhm.developer.monkey.common.constant;

/**
 * 项目常量类
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-02 21:14:42
 */
public interface ProjectConstant {

    /**
     * 项目运行状态
     */
    interface AppStatus {

        /**
         * 正在启动中
         */
        String STARTING = "Starting";

        /**
         * 运行中
         */
        String UP = "up";
        
        /**
         * 项目关闭
         */
        String DOWN = "down";
    }

    /**
     * 请求
     */
    interface Request {

        /**
         * 跟踪ID键值
         */
        String TRACE_ID_KEY = "TRACE_ID";
    }
}
