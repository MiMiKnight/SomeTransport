package cn.yhm.developer.monkey.service;

import cn.yhm.developer.monkey.model.entity.ContentEntity;

import java.util.List;

/**
 * 内容模块Service
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 17:58:29
 */
public interface ContentService {

    /**
     * 保存一条记录
     *
     * @param entity 实体类
     * @return {@link Long}
     */
    Integer save(ContentEntity entity);

    /**
     * 根据主键获取内容表的一条记录
     *
     * @param key 主键
     * @return {@link ContentEntity}
     */
    ContentEntity selectContentByPrimaryKey(Long key);

    /**
     * 根据主键集合查询记录
     *
     * @param idList 主键集合
     * @return {@link List}<{@link ContentEntity}>
     */
    List<ContentEntity> selectContentByIdList(List<Long> idList);


    /**
     * 通过主键更新实体类
     *
     * @param entity 实体类
     * @return {@link Integer}
     */
    Integer updateByPrimaryKey(ContentEntity entity);
}
