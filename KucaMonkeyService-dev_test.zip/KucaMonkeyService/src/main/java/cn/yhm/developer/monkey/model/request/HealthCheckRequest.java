package cn.yhm.developer.monkey.model.request;

import cn.yhm.developer.kuca.ecology.model.request.EcologyRequest;
import lombok.Getter;
import lombok.Setter;

/**
 * 健康检查请求入参
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-02 21:06:56
 */
@Setter
@Getter
public class HealthCheckRequest implements EcologyRequest {
}
