package cn.yhm.developer.monkey.rest.controller;

import cn.yhm.developer.kuca.ecology.rest.controller.AbstractEcologyHandlerAdapter;
import cn.yhm.developer.monkey.model.request.GetContentByIdRequest;
import cn.yhm.developer.monkey.model.request.SaveContentRequest;
import cn.yhm.developer.monkey.model.request.UpdateContentByIdRequest;
import cn.yhm.developer.monkey.model.response.GetContentByIdResponse;
import cn.yhm.developer.monkey.model.response.SaveContentResponse;
import cn.yhm.developer.monkey.model.response.UpdateContentByIdResponse;
import cn.yhm.developer.monkey.rest.handler.GetContentByIdHandler;
import cn.yhm.developer.monkey.rest.handler.SaveContentHandler;
import cn.yhm.developer.monkey.rest.handler.UpdateContentByIdHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 内容模块前端控制器
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 12:48:17
 */
@Slf4j
@RestController
@RequestMapping(value = {Controller.Content.MODULE_VISIT_PREFIX}, produces = {MediaType.APPLICATION_JSON_VALUE})
public class ContentController extends AbstractEcologyHandlerAdapter implements Controller.Content {

    @PostMapping(value = {"/save"})
    @Override
    public SaveContentResponse saveContent(@RequestBody @Validated SaveContentRequest request) throws Exception {
        return handle(request, SaveContentHandler.class);
    }

    @PostMapping(value = "/get-content-by-id")
    @Override
    public GetContentByIdResponse getContentById(@RequestBody @Validated GetContentByIdRequest request) throws Exception {
        return handle(request, GetContentByIdHandler.class);
    }

    @PostMapping(value = "/update-content-by-id")
    @Override
    public UpdateContentByIdResponse updateContentById(@RequestBody @Validated UpdateContentByIdRequest request) throws Exception {
        return handle(request, UpdateContentByIdHandler.class);
    }
}
