package cn.yhm.developer.monkey.model.response;

import cn.yhm.developer.kuca.ecology.model.response.SuccessResponse;
import lombok.Getter;
import lombok.Setter;

/**
 * @author victor2015yhm@gmail.com
 * @since 2022-12-11 21:39:55
 */
@Setter
@Getter
public class UpdateContentByIdResponse extends SuccessResponse {
}
