package cn.yhm.developer.monkey.common.init;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;

/**
 * 雪花ID生成器初始化配置类
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-11 23:46:44
 */
@Slf4j
@Order(value = 0)
public class SnowFlakeIdGeneratorInitConfig implements CommandLineRunner {

    @Override
    public void run(String... args) throws Exception {
        // 获取mac地址
        log.info("SnowFlakeIdGeneratorInitRunner...run()...");

    }
}
