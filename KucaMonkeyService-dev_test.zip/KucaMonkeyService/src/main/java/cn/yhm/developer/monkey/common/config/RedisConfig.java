package cn.yhm.developer.monkey.common.config;

import org.springframework.context.annotation.Configuration;

/**
 * Redis配置类
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-13 06:47:25
 */
@Configuration
public class RedisConfig {
}
