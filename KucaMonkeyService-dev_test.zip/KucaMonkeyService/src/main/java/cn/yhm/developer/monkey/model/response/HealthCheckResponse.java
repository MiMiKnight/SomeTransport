package cn.yhm.developer.monkey.model.response;

import cn.yhm.developer.kuca.ecology.model.response.EcologyResponse;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * 健康检查请求出参
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-02 21:06:19
 */
@Setter
@Getter
public class HealthCheckResponse implements EcologyResponse {

    /**
     * 应用名称
     */
    @JsonProperty(value = "app_name")
    private String appName;

    /**
     * 运行状态
     */
    @JsonProperty(value = "status")
    private String status;
}
