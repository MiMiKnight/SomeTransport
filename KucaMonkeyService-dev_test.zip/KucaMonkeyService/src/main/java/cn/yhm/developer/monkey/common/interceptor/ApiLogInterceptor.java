package cn.yhm.developer.monkey.common.interceptor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * api接口日志记录拦截器
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-02 07:38:54
 */
@Slf4j
@Component
public class ApiLogInterceptor implements HandlerInterceptor {
    /**
     * 打印入参日志
     *
     * @param request  请求
     * @param response 响应
     * @param handler  处理器
     * @return boolean 是否继续执行
     * @throws Exception 异常
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // TODO:打印入参日志
        // 请求方法
        String method = request.getMethod();
        // 访问路径
        String requestURI = request.getRequestURI();
        // 目的地址
        String destination = request.getRemoteAddr();
        // 源地址
        String source = request.getLocalAddr();
        // 参数
        String queryString = request.getQueryString();

        return HandlerInterceptor.super.preHandle(request, response, handler);
    }

    /**
     * 打印出参日志
     *
     * @param request  请求
     * @param response 响应
     * @param handler  处理器
     * @param ex       异常
     * @throws Exception 异常
     */
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        // TODO:打印出参日志
        log.info("Response::{}", 1);
        HandlerInterceptor.super.afterCompletion(request, response, handler, ex);
    }
}
