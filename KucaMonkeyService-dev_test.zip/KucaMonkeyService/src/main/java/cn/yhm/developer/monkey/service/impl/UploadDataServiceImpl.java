package cn.yhm.developer.monkey.service.impl;

import cn.yhm.developer.monkey.common.utils.FutureUtils;
import cn.yhm.developer.monkey.service.UploadDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * 上传数据服务实现类
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-01-14 23:57:53
 */
@Slf4j
@Service
public class UploadDataServiceImpl implements UploadDataService {
    @Resource
    private ThreadPoolTaskExecutor executor;

    @Resource
    private FutureUtils futureUtils;

    @Override
    public void getHello() {
        this.asyncHandleData(5);
    }

    /**
     * 每次100条数据，5个线程，每个线程20条数据
     *
     * @param threadNum
     */
    private void asyncHandleData(int threadNum) {
        // 16组数据，分2个线程处理，每个线程一次最多处理4条数据
        List<Integer> dataList = Arrays.asList(1, 2, 3, 4, 5);
        List<CompletableFuture<Integer>> futures = dataList.stream().map(result ->
                (Supplier<Integer>) () -> {
                    int i = result + 1;
                    log.info("thread result = {}", i);
                    return i;
                }
        ).map(supplier ->
                futureUtils.supplyAsync(supplier, e -> {
                    log.error("thread exception message = {}", e.getMessage());
                    return 100;
                }, 100, 10, TimeUnit.SECONDS)
        ).collect(Collectors.toList());
        CompletableFuture.allOf(futures.toArray(CompletableFuture[]::new)).join();
        log.info("results = {}", Arrays.toString(futures.stream().map(CompletableFuture::join).toArray()));
    }

    private <T> CompletableFuture<T> getFutureOrTimeOut(Supplier<T> supplier, T timeoutValue, long timeout, TimeUnit unit) {
        return CompletableFuture.supplyAsync(supplier).completeOnTimeout(timeoutValue, timeout, unit);
    }
}
