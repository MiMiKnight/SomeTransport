package cn.yhm.developer.monkey.model.entity;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * 内容表实体类
 * <p>
 * 映射表 t_monkey_content
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 15:33:28
 */
@Getter
@Setter
public class ContentEntity {

    /**
     * 主键
     * <p>
     * 映射字段：id
     */
    private Long id;

    /**
     * 内容
     * <p>
     * 映射字段：content
     */
    private String content;

    /**
     * 乐观锁字段
     * <p>
     * 映射字段：version
     * <p>
     * 初始值：0 每次有字段更新时自增+1
     */
    private Integer version;

    /**
     * 逻辑删除
     * <p>
     * 映射字段：deleted
     * <p>
     * 删除：1 未删除：0
     */
    private Integer deleted;

    /**
     * 创建时间
     * <p>
     * 映射字段：create_time
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     * <p>
     * 映射字段：update_time
     */
    private LocalDateTime updateTime;
}
