package cn.yhm.developer.monkey.rest.controller;

import cn.yhm.developer.monkey.model.request.GetContentByIdRequest;
import cn.yhm.developer.monkey.model.request.HealthCheckRequest;
import cn.yhm.developer.monkey.model.request.SaveContentRequest;
import cn.yhm.developer.monkey.model.request.UpdateContentByIdRequest;
import cn.yhm.developer.monkey.model.response.GetContentByIdResponse;
import cn.yhm.developer.monkey.model.response.HealthCheckResponse;
import cn.yhm.developer.monkey.model.response.SaveContentResponse;
import cn.yhm.developer.monkey.model.response.UpdateContentByIdResponse;

/**
 * 前端控制器接口
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-02 20:16:34
 */
public interface Controller {
    String TOP_VISIT_PREFIX = "/rest/developer/monkey";

    /**
     * 健康检查模块
     */
    interface Health {
        String MODULE_VISIT_PREFIX = TOP_VISIT_PREFIX + "/health";

        /**
         * 健康检查方法
         *
         * @param request 请求参数
         * @return {@link HealthCheckResponse}
         * @throws Exception 异常
         */
        HealthCheckResponse healthCheck(HealthCheckRequest request) throws Exception;
    }

    /**
     * 内容模块
     */
    interface Content {
        String MODULE_VISIT_PREFIX = TOP_VISIT_PREFIX + "/content";

        /**
         * 保存内容的方法
         *
         * @param request 请求参数
         * @return {@link SaveContentResponse}
         * @throws Exception 异常
         */
        SaveContentResponse saveContent(SaveContentRequest request) throws Exception;

        /**
         * 根据内容id获取内容
         *
         * @param request 请求参数
         * @return {@link GetContentByIdResponse}
         * @throws Exception 异常
         */
        GetContentByIdResponse getContentById(GetContentByIdRequest request) throws Exception;

        /**
         * 根据ID更新内容
         *
         * @param request 请求参数
         * @return {@link UpdateContentByIdResponse}
         * @throws Exception 异常
         */
        UpdateContentByIdResponse updateContentById(UpdateContentByIdRequest request) throws Exception;
    }
}
