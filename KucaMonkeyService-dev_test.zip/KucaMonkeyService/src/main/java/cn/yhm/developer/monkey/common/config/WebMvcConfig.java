package cn.yhm.developer.monkey.common.config;

import cn.yhm.developer.monkey.common.interceptor.RequestTraceInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Web MVC 配置类
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-02 19:43:58
 */
@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    /**
     * 配置拦截器
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        String[] paths = {"/**"};
        String[] excludePaths = {"/error"};
        // 添加请求跟踪拦截器
        registry.addInterceptor(new RequestTraceInterceptor()).addPathPatterns(paths).excludePathPatterns(excludePaths);
        // 添加API入参出参日志打印拦截器
        // registry.addInterceptor(new ApiLogInterceptor()).addPathPatterns(paths).excludePathPatterns(excludePaths);
    }
}
