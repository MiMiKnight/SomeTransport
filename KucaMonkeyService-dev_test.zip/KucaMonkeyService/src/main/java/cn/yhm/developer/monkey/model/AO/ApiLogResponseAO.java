package cn.yhm.developer.monkey.model.AO;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * API接口日志响应出参应用对象
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 15:34:17
 */
@ToString
@Getter
@Setter
public class ApiLogResponseAO<T> {

    /**
     * HTTP方法
     */
    @JsonProperty(value = "method", index = 1)
    private String method;

    /**
     * 响应状态码
     */
    @JsonProperty(value = "http_status", index = 2)
    private Integer httpStatus;

    /**
     * 访问路径
     */
    @JsonProperty(value = "path", index = 3)
    private String path;

    /**
     * 源IP地址
     */
    @JsonProperty(value = "source", index = 4)
    private String source;

    /**
     * 目的IP地址
     */
    @JsonProperty(value = "destination", index = 5)
    private String destination;

    /**
     * 参数
     */
    @JsonProperty(value = "parameter", index = 6)
    private T parameter;
}
