package cn.yhm.developer.monkey.common.constant;

/**
 * 缓存键的常量
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 22:57:04
 */
public interface CacheKeyConstant {

    /**
     * 分隔符
     */
    String SEPARATOR = ":";

    /**
     * 项目顶级缓存前缀
     */
    String TOP_CACHE_PREFIX = "MonkeyService" + SEPARATOR;

    /**
     * 公共模块
     */
    interface Common {
        /**
         * 当前模块缓存前缀
         */
        String MODULE_CACHE_PREFIX = TOP_CACHE_PREFIX + "Common" + SEPARATOR;
    }

    /**
     * Content模块
     */
    interface Content {

        /**
         * 当前模块缓存前缀
         */
        String MODULE_CACHE_PREFIX = TOP_CACHE_PREFIX + "Content" + SEPARATOR;

        /**
         * 更新锁
         */
        String UPDATE_CONTENT_LOCK = MODULE_CACHE_PREFIX + "Lock-Update-Content";

    }

}
