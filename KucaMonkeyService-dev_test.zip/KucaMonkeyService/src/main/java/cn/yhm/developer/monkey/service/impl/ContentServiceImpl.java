package cn.yhm.developer.monkey.service.impl;

import cn.yhm.developer.kuca.common.constant.TimeZone;
import cn.yhm.developer.kuca.common.utils.DateUtils;
import cn.yhm.developer.monkey.mapper.ContentMapper;
import cn.yhm.developer.monkey.model.entity.ContentEntity;
import cn.yhm.developer.monkey.service.ContentService;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

/**
 * Content模块Service实现类
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 18:00:09
 */
@Service
public class ContentServiceImpl implements ContentService {
    @Resource
    private ContentMapper contentMapper;


    @Override
    public Integer save(ContentEntity entity) {
        entity.setId(11L);
        entity.setVersion(0);
        LocalDateTime now = LocalDateTime.now(ZoneId.of(TimeZone.UTC.ZERO));
        entity.setCreateTime(now);
        entity.setUpdateTime(now);
        return contentMapper.save(entity);
    }

    @Override
    public ContentEntity selectContentByPrimaryKey(Long key) {
        Assert.notNull(key, "The parameter can not be null");
        return contentMapper.selectContentByPrimaryKey(key);
    }

    @Override
    public List<ContentEntity> selectContentByIdList(List<Long> idList) {
        Assert.notEmpty(idList, "The content id list can not be null or empty");
        return contentMapper.selectContentByIdList(idList);
    }

    @Override
    public Integer updateByPrimaryKey(ContentEntity entity) {
        Assert.notNull(entity, "The parameter can not be null");
        DateUtils dateUtils = new DateUtils();
        // 更新时间
        LocalDateTime updateTime = dateUtils.getUTCZonedDateTime().toLocalDateTime();
        entity.setUpdateTime(updateTime);
        return contentMapper.updateByPrimaryKey(entity);
    }
}
