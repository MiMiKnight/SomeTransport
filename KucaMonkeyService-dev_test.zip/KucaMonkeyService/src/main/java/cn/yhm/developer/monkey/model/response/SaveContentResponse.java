package cn.yhm.developer.monkey.model.response;

import cn.yhm.developer.kuca.ecology.model.response.SuccessResponse;
import lombok.Getter;
import lombok.Setter;

/**
 * 保存内容请求参数
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-03 12:52:48
 */
@Setter
@Getter
public class SaveContentResponse extends SuccessResponse {
}
