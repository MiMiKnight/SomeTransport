package cn.yhm.developer.monkey.rest.handler;

import cn.yhm.developer.kuca.common.utils.RedissonUtils;
import cn.yhm.developer.kuca.ecology.rest.handler.EcologyHandleable;
import cn.yhm.developer.monkey.model.entity.ContentEntity;
import cn.yhm.developer.monkey.model.request.UpdateContentByIdRequest;
import cn.yhm.developer.monkey.model.response.UpdateContentByIdResponse;
import cn.yhm.developer.monkey.service.ContentService;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.annotation.Resource;

/**
 * @author victor2015yhm@gmail.com
 * @since 2022-12-11 21:42:08
 */
@Component
public class UpdateContentByIdHandler implements EcologyHandleable<UpdateContentByIdRequest, UpdateContentByIdResponse> {

    @Resource
    private ContentService contentService;

    @Resource
    private RedissonUtils redissonUtils;

    @Override
    public UpdateContentByIdResponse handle(UpdateContentByIdRequest request) throws Exception {
        Long id = request.getId();
        ContentEntity contentEntity = contentService.selectContentByPrimaryKey(id);
        Assert.notNull(contentEntity, "The primary key is invalid");
        contentEntity.setContent(request.getContent());
        // 更新
        Integer rows = contentService.updateByPrimaryKey(contentEntity);
        Assert.state(rows >= 1, "Update failed");
        UpdateContentByIdResponse response = new UpdateContentByIdResponse();
        return response;
    }
}
