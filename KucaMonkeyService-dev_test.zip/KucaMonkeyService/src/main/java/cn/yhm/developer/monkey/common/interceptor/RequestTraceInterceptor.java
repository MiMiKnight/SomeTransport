package cn.yhm.developer.monkey.common.interceptor;

import cn.yhm.developer.monkey.common.constant.ProjectConstant;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.UUID;

/**
 * 请求跟踪拦截器
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-12-02 07:54:04
 */
@Slf4j
@Component
public class RequestTraceInterceptor implements HandlerInterceptor {

    /**
     * 为当前请求线程设置跟踪ID
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        // 请求跟踪ID
        String traceId = UUID.randomUUID().toString().replace("-", "");
        // 设置当前请求线程中的跟踪ID
        MDC.put(ProjectConstant.Request.TRACE_ID_KEY, traceId);
        return true;
    }

    /**
     * 清除当前请求线程的跟踪ID
     */
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
        // 清除当前请求线程中的跟踪ID
        MDC.clear();
    }
}
