package cn.yhm.developer.monkey.common.enumeration;

/**
 * @author victor2015yhm@gmail.com
 * @since 2022-12-11 17:01:25
 */
public enum TableType {

    /**
     * 内容表时
     */
    Content();
}
