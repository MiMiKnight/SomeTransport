package cn.yhm.developer.monkey.common.exception;

import lombok.Getter;

/**
 * 自定义业务异常
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-10 19:04:16
 */
@Getter
public class ServiceException extends RuntimeException {

    private final String errorCode;

    public ServiceException(String errorCode) {
        this.errorCode = errorCode;
    }
}
