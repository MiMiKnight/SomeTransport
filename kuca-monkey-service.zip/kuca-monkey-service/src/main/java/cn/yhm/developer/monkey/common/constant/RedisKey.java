package cn.yhm.developer.monkey.common.constant;

/**
 * Redis键名
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-02 15:25:21
 */
public interface RedisKey {

    /**
     * 公共模块
     */
    interface Common {
        /**
         * 当前模块缓存前缀
         */
        String MODULE_CACHE_PREFIX = "Common";

        /**
         * 锁
         */
        interface Lock {

        }

        /**
         * 缓存
         */
        interface Cache {

        }

    }

    /**
     * Content模块
     */
    interface Content {

        /**
         * 当前模块缓存前缀
         */
        String MODULE_PREFIX = "Content";

        /**
         * 锁
         */
        interface Lock {
            /**
             * 内容更新锁
             */
            String UPDATE_CONTENT = buildLock(MODULE_PREFIX, "Update-Content");
        }

        /**
         * 缓存
         */
        interface Cache {

            /**
             * 内容缓存
             */
            String UPDATE_CONTENT = buildCache(MODULE_PREFIX, "Update-Content");
        }


    }

    //*********************************************************************************************//

    /**
     * 构建
     *
     * @param top       顶级前缀
     * @param module    模块
     * @param type      类型
     * @param lock      锁
     * @param separator 分隔符
     * @return {@link String}
     */
    static String build(String top, String module, String type, String lock, String separator) {
        StringBuffer lockName = new StringBuffer();
        return lockName.append(top).append(separator)
                .append(module)
                .append(separator)
                .append(type)
                .append(separator)
                .append(lock).toString();
    }

    /**
     * 建立锁
     * 构造锁
     *
     * @param module   模块名
     * @param lockName 锁名
     * @return {@link String}
     */
    static String buildLock(String module, String lockName) {
        return build(ProjectConstant.Cache.TOP_PREFIX, module, ProjectConstant.Cache.LOCK_TYPE, lockName,
                ProjectConstant.Cache.SEPARATOR);
    }

    /**
     * 建立缓存
     * 构造锁
     *
     * @param module    模块名
     * @param cacheName 缓存名称
     * @return {@link String}
     */
    static String buildCache(String module, String cacheName) {
        return build(ProjectConstant.Cache.TOP_PREFIX, module, ProjectConstant.Cache.CACHE_TYPE, cacheName,
                ProjectConstant.Cache.SEPARATOR);
    }

}
