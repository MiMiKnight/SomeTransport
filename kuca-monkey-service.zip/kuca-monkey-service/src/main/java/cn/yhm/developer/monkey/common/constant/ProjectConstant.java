package cn.yhm.developer.monkey.common.constant;

/**
 * 项目常量
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-12 10:39:05
 */
public interface ProjectConstant {

    /**
     * 项目相关常量
     */
    interface App {

        /**
         * 项目名称
         */
        String NAME = "MonkeyService";
    }

    /**
     * 缓存
     */
    interface Cache {
        /**
         * 缓存分隔符
         */
        String SEPARATOR = ":";

        /**
         * 项目缓存顶级前缀
         */
        String TOP_PREFIX = ProjectConstant.App.NAME;

        /**
         * 锁
         */
        String LOCK_TYPE = "Lock";

        /**
         * 缓存
         */
        String CACHE_TYPE = "Cache";
    }

    /**
     * 日志相关常量
     */
    interface Log {

        /**
         * MDC跟踪Key
         */
        String MDC_TRACE_ID_KEY = "TRACE_ID";

        /**
         * API request 日志格式
         * <p>
         * Method：请求类型（Get、Post、Delete、Put、Patch...）
         * <p>
         * Path：接口路径
         * <p>
         * Request：请求参数
         */

        String API_LOG_REQUEST_FORMAT = "|Method={}|URI={}|Request={}|";

        /**
         * API response 日志格式
         * <p>
         * Total：接口响应总耗时
         * <p>
         * Status：当前响应状态码
         * <p>
         * Method：请求类型（Get、Post、Delete、Put、Patch...）
         * <p>
         * URI：请求访问路径
         * <p>
         * Response：响应内容
         */
        String API_LOG_RESPONSE_FORMAT = "|Cost={}ns|Status={}|Method={}|URI={}|Response={}|";
    }
}
