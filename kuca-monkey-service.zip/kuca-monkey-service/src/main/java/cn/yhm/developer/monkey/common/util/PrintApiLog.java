package cn.yhm.developer.monkey.common.util;

import cn.yhm.developer.monkey.common.constant.ProjectConstant;
import lombok.extern.slf4j.Slf4j;

import java.lang.reflect.Parameter;

/**
 * 打印api日志
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-02 15:25:11
 */
@Slf4j
public class PrintApiLog {

    public static void printRequestApiLog(String uri, // 接口路径
                                          String requestMethod,
                                          Parameter[] parameters,
                                          Object[] args) {
        log.info(ProjectConstant.Log.API_LOG_REQUEST_FORMAT, requestMethod, uri, "request-params");
    }

    public static void printResponseApiLog(long cost, // 耗时
                                           int status,
                                           String uri,
                                           String requestMethod,
                                           Parameter[] parameters,
                                           Object[] args) {
        log.info(ProjectConstant.Log.API_LOG_RESPONSE_FORMAT, cost, status, requestMethod, uri,
                "response-params");
    }
}
