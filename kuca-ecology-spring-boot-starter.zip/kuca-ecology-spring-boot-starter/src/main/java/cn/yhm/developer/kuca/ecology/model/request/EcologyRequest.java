package cn.yhm.developer.kuca.ecology.model.request;

/**
 * 请求参数接口
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-08 23:36:33
 */
public interface EcologyRequest {
}
