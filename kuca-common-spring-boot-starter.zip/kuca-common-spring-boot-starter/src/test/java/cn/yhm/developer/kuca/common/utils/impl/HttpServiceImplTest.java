package cn.yhm.developer.kuca.common.utils.impl;

import cn.yhm.developer.kuca.common.model.request.AuditContentRequest;
import cn.yhm.developer.kuca.common.utils.standard.HttpService;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

@Slf4j
@SpringBootConfiguration
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK,
        classes = {HttpServiceImpl.class,
                RestTemplate.class,
                JsonServiceImpl.class})
public class HttpServiceImplTest {

    private HttpService httpService;

    @Autowired
    public void setHttpService(HttpService httpService) {
        this.httpService = httpService;
    }

    @Test
    void doGet() {

    }

    @Test
    void doGet_2() {
        String domain = "http://127.0.0.1:8443";
        String path = "/rest/developer/monkey-service/health/v1/check";
        HttpHeaders httpHeaders = httpService.jsonContentTypeHttpHeaders();
        ResponseEntity<String> responseEntity = httpService.doGet(domain, path, httpHeaders);
        int statusCode = responseEntity.getStatusCodeValue();
        String body = responseEntity.getBody();
        log.info("status code = {}", statusCode);
        log.info("response body = {}", body);
    }

    @Test
    void doGet_3() {
    }

    @Test
    void doPost() {
        String apiDomain = "http://127.0.0.1:8443";
        String apiPath = "/rest/developer/monkey-service/content/v1/audit";
        HttpHeaders httpHeaders = httpService.jsonContentTypeHttpHeaders();

        AuditContentRequest requestBody = new AuditContentRequest();
        requestBody.setAuditResult(1);
        requestBody.setAuditTime("2022-12-12 06:32:34.000 +0800");

        ResponseEntity<String> responseEntity = httpService.doPost(apiDomain, apiPath, httpHeaders, requestBody);
        int statusCode = responseEntity.getStatusCodeValue();
        String body = responseEntity.getBody();
        log.info("status code = {}", statusCode);
        log.info("response body = {}", body);
    }

    @Test
    void doPut() {
    }

    @Test
    void doDelete() {
    }

    @Test
    void doPatch() {
    }
}