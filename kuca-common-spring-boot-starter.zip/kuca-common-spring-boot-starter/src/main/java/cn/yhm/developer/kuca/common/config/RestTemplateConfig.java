package cn.yhm.developer.kuca.common.config;

import cn.yhm.developer.kuca.common.http.CustomResponseErrorHandler;
import cn.yhm.developer.kuca.common.http.ApiLogInterceptor;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.web.client.ResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/**
 * RestTemplate配置类
 * <p>
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-06 21:44:12
 */
@Configuration
public class RestTemplateConfig {

    interface LocalConstant {

        /**
         * 连接超时 时间
         * <p>
         * 默认：5秒
         */
        Duration CONNECT_TIMEOUT = Duration.of(5, ChronoUnit.SECONDS);

        /**
         * 读取超时 时间
         * <p>
         * 请求执行最大耗时限制
         * <p>
         * 默认：10秒
         */
        Duration READ_TIMEOUT = Duration.of(20, ChronoUnit.SECONDS);
    }

    @Bean(name = "restTemplate")
    public RestTemplate restTemplate() {
        // TODO: 1、解决HTTPS访问的问题
        // TODO: 2、解决响应body为空的问题
        // TODO: 3、使用OkHttpClient
        // TODO: 4、自定义连接池
        return new RestTemplateBuilder()
                .setConnectTimeout(LocalConstant.CONNECT_TIMEOUT)
                .setReadTimeout(LocalConstant.READ_TIMEOUT)
                .interceptors(getHttpRequestInterceptor())
                .errorHandler(getResponseErrorHandler())
                .build();
    }

    private ResponseErrorHandler getResponseErrorHandler() {
        return new CustomResponseErrorHandler();
    }

    private List<ClientHttpRequestInterceptor> getHttpRequestInterceptor() {
        // 拦截器集合
        List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
        // 添加接口日志打印拦截器
        interceptors.add(new ApiLogInterceptor());
        return interceptors;
    }

}
