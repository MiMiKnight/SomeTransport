package cn.yhm.developer.kuca.common.utils.standard;

import org.redisson.api.RLock;

import java.util.concurrent.TimeUnit;

/**
 * Redisson分布式锁工具类接口
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-03-24 20:40:22
 */
public interface RedissonService {

    /**
     * Redis加锁
     *
     * @param lockKey    Redis锁键
     * @param unit       时间单位
     * @param expireTime 上锁后自动释放锁的时间（锁失效时间）
     * @return {@link RLock}
     */
    RLock lock(String lockKey, TimeUnit unit, long expireTime);

    /**
     * Redis加锁
     * <p>
     * 失效时间单位：秒
     *
     * @param lockKey    Redis锁键
     * @param expireTime 上锁后自动释放锁的时间（锁失效时间）
     * @return {@link RLock}
     */
    RLock lock(String lockKey, long expireTime);

    /**
     * Redis加锁
     * <p>
     * 没有失效时间，永久生效
     *
     * @param lockKey Redis锁键
     * @return {@link RLock}
     */
    RLock lock(String lockKey);

    /**
     * Redis加锁
     * <p>
     * 如果获取锁成功，则返回true；如果在等待时间内未获取到锁，则返回false
     *
     * @param lockKey  Redis锁键
     * @param waitTime 等待获取锁的时间
     * @param unit     时间单位
     * @return boolean
     */
    boolean tryLock(String lockKey, long waitTime, TimeUnit unit);

    /**
     * Redis加锁
     * <p>
     * 如果获取锁成功，则返回true；如果在等待时间内未获取到锁，则返回false
     * <p>
     * 默认时间单位：秒
     *
     * @param lockKey    Redis锁键
     * @param waitTime   等待获取锁的时间
     * @param expireTime 上锁后自动释放锁的时间（锁失效时间）
     * @return boolean
     */
    boolean tryLock(String lockKey, long waitTime, long expireTime);

    /**
     * Redis加锁
     * <p>
     * 如果获取锁成功，则返回true；如果在等待时间内未获取到锁，则返回false
     *
     * @param lockKey    Redis锁键
     * @param unit       时间单位
     * @param waitTime   等待获取锁的时间
     * @param expireTime 上锁后自动释放锁的时间（锁失效时间）
     * @return boolean
     */
    boolean tryLock(String lockKey, TimeUnit unit, long waitTime, long expireTime);

    /**
     * 释放锁
     * <p>
     * 若没用锁情况下，就不调用释放锁的代码，若有锁情况下才调用释放锁
     *
     * @param lockKey Redis锁键
     */
    void unlock(String lockKey);

    /**
     * 释放锁
     * <p>
     * 若没用锁情况下，就不调用释放锁的代码，若有锁情况下才调用释放锁
     *
     * @param lock Redis锁对象
     */
    void unlock(RLock lock);
}
