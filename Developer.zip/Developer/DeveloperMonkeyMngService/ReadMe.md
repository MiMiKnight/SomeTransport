# 项目名称: DeveloperMonkeyMngService

## 项目简介：

>
>

## 项目目录结构：
```txt
src
 ├── main
 │    ├── java
 │    │     └── cn.yhm.developer.monkey
 │    │            ├── bean
 │    │            ├── common
 │    │            ├── mapper
 │    │            ├── rest
 │    │               │     ├── controller
 │    │            │     └── handler 
 │    │            ├── service
 │    │            └── Application.java
 │    │
 │    └── resource
 │
 │
 │   
 └── test
```

## 项目代办事项：

> - 请求跟踪ID
> 

##
> -d64
-server
-Dfile.encoding=UTF-8
-Duser.timezone=UTC