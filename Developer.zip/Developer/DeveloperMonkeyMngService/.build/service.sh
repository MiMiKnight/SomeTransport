# !/bin/bash

# JVM Option
JVM_Option = "-d64 \
              -server \
              -Duser.timezone=UTC \
              -Dfile.encoding=UTF-8"