package cn.yhm.developer.monkey.service;

/**
 * 健康服务接口
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-09-04 19:41:53
 */
public interface HealthService {

    /**
     * doHealth
     */
    void doHealth();
}
