package cn.yhm.developer.monkey.service.impl;

import cn.yhm.developer.monkey.service.HealthService;
import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * 健康服务实现类
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-09-04 19:41:13
 */
@Slf4j
@Service
public class HealthServiceImpl implements HealthService {
    @Override
    public void doHealth() {
        log.info("doHealth....");
    }
}
