package cn.yhm.developer.monkey.service;

import cn.yhm.developer.monkey.model.entity.ContentEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @author victor2015yhm@gmail.com
 * @since 2022-09-06 23:50:59
 */
public interface ContentService extends IService<ContentEntity> {
}
