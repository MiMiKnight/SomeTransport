package cn.yhm.developer.monkey.model.response;

import cn.yhm.developer.ecology.constant.DateTimeFormat;
import cn.yhm.developer.ecology.constant.TimeZoneGMT;
import cn.yhm.developer.ecology.model.response.GatewayResponse;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * 健康检查响应
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-09-04 17:01:38
 */
@Getter
@Setter
@Builder
public class HealthCheckResponse implements GatewayResponse {

    /**
     * 项目名称
     */
    @JsonProperty(value = "app_name", index = 1, access = JsonProperty.Access.READ_ONLY)
    private String appName;

    /**
     * 项目状态
     */
    @JsonProperty(value = "status", index = 2, access = JsonProperty.Access.READ_ONLY)
    private String status;

    /**
     * 时间戳
     */
    @JsonFormat(pattern = DateTimeFormat.STANDARD_4, timezone = TimeZoneGMT.GMT_0)
    @JsonProperty(value = "timestamp", index = 3, access = JsonProperty.Access.READ_ONLY)
    private Date timestamp;
}
