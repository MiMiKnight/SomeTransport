package cn.yhm.developer.monkey.rest.controller;

import cn.yhm.developer.ecology.rest.controller.GatewayController;
import cn.yhm.developer.monkey.model.request.HealthCheckRequest;
import cn.yhm.developer.monkey.model.response.HealthCheckResponse;
import cn.yhm.developer.monkey.rest.handler.HealthCheckHandler;
import cn.yhm.developer.monkey.service.HealthService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * 健康控制器
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-09-04 16:49:15
 */
@Slf4j
@RestController
@RequestMapping(value = {"/health"})
public class HealthController extends GatewayController {

    @GetMapping(value = {""})
    public HealthCheckResponse healthCheck(HealthCheckRequest request) throws Exception {
        return handle(request, HealthCheckHandler.class);
    }
}
