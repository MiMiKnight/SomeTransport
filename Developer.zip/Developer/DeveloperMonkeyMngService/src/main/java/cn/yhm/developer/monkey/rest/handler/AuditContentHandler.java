package cn.yhm.developer.monkey.rest.handler;

import cn.yhm.developer.ecology.rest.handler.GatewayHandler;
import cn.yhm.developer.ecology.utils.DateUtils;
import cn.yhm.developer.monkey.model.entity.ContentEntity;
import cn.yhm.developer.monkey.model.request.AuditContentRequest;
import cn.yhm.developer.monkey.model.response.AuditContentResponse;
import cn.yhm.developer.monkey.service.ContentService;
import cn.yhm.developer.monkey.service.HealthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.annotation.Resources;
import java.text.ParseException;
import java.util.Date;


/**
 * @author victor2015yhm@gmail.com
 * @since 2022-10-07 10:51:10
 */
@Component
public class AuditContentHandler implements GatewayHandler<AuditContentRequest, AuditContentResponse> {

    @Resource
    private ContentService contentService;

    @Override
    public AuditContentResponse handle(AuditContentRequest request) throws Exception {
        ContentEntity entity = contentService.getById("002ab2a8c0830ca036fa863583373f66");
        return AuditContentResponse.builder().build();
    }
}