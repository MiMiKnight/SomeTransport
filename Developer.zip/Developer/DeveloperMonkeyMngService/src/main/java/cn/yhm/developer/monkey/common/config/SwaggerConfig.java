package cn.yhm.developer.monkey.common.config;

import org.springframework.context.annotation.Configuration;

/**
 * Swagger配置类
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-10-07 19:34:42
 */
@Configuration
public class SwaggerConfig {
}
