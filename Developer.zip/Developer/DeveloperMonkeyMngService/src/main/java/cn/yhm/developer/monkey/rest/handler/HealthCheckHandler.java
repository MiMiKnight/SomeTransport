package cn.yhm.developer.monkey.rest.handler;

import cn.yhm.developer.ecology.rest.handler.GatewayHandler;
import cn.yhm.developer.monkey.model.request.HealthCheckRequest;
import cn.yhm.developer.monkey.model.response.HealthCheckResponse;
import cn.yhm.developer.monkey.service.HealthService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;

/**
 * 健康检查处理器
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-10-07 15:59:34
 */
@Component
public class HealthCheckHandler implements GatewayHandler<HealthCheckRequest, HealthCheckResponse> {

    @Value("${spring.application.name}")
    private String appName;


    @Resource
    private HealthService healthService;

    @Override
    public HealthCheckResponse handle(HealthCheckRequest request) throws Exception {
        return HealthCheckResponse.builder().appName(appName).status("running").timestamp(new Date()).build();
    }
}
