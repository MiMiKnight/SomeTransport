package cn.yhm.developer.ecology.model.response;

/**
 * 响应接口
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-09-04 09:34:35
 */
public interface GatewayResponse {
}
