package cn.yhm.developer.ecology.model.request;

/**
 * 请求接口
 *
 * @author victor2015yhm@gmail.com
 * @since 2022-09-04 09:34:35
 */
public interface GatewayRequest {
}
