# DeveloperFoundationParent

## v1.0.0
> - spring-boot-dependencies v2.6.3
> - spring-cloud-dependencies v2021.0.1
> - spring-cloud-alibaba-dependencies v2021.0.1.0
> - mysql-connector-java v8.0.29
> - druid-spring-boot-starter v1.2.11
> - HikariCP v5.0.1
> - mybatis-plus-boot-starter v3.5.2
> - mybatis-plus-generator v3.5.3
> - lombok v1.18.24
> - springfox-boot-starter v3.0.0
> - commons-lang3 v3.12.0
> - commons-io v2.11.0
> - commons-pool2 v2.11.1
> - commons-collections4 v4.4
> - joda-time v2.10.14
> - easyexcel v3.1.1
> - jackson-core v2.13.3