package cn.yhm.developer.desensitize.strategy;

/**
 * 敏感策略接口
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-05-22 02:16:06
 */
public interface SensitiveStrategy {

    /**
     * 脱敏方法
     *
     * @param text 待被脱敏文本
     * @return {@link String}
     */
    String desensitize(String text);
}
