package cn.yhm.developer.monkey.mapper;

import cn.yhm.developer.monkey.entity.ContentEntity;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 内容表 Mapper 接口
 * </p>
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-06-05 07:22:56
 */
@Mapper
public interface ContentMapper extends BaseMapper<ContentEntity> {

}
