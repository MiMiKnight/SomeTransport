package cn.yhm.developer.monkey.service.impl;

import cn.yhm.developer.monkey.entity.ContentEntity;
import cn.yhm.developer.monkey.mapper.ContentMapper;
import cn.yhm.developer.monkey.service.standard.ContentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 内容表 服务实现类
 * </p>
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-06-05 07:22:56
 */
@Service
public class ContentServiceImpl extends ServiceImpl<ContentMapper, ContentEntity> implements ContentService {

}
