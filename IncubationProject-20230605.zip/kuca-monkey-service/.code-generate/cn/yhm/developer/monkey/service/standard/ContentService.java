package cn.yhm.developer.monkey.service.standard;

import cn.yhm.developer.monkey.entity.ContentEntity;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 内容表 服务类
 * </p>
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-06-05 07:22:56
 */
public interface ContentService extends IService<ContentEntity> {

}
