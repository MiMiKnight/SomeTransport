package cn.yhm.developer.monkey.controller;

import cn.yhm.developer.kuca.ecology.core.EcologyRequestHandleAdapter;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 内容表 前端控制器
 * </p>
 *
 * @author victor2015yhm@gmail.com
 * @since 2023-06-05 07:22:56
 */
@Validated
@RestController
@RequestMapping(path = "/monkey/content-entity",
        consumes = {MediaType.APPLICATION_JSON_VALUE},
        produces = {MediaType.APPLICATION_JSON_VALUE})
public class ContentController extends EcologyRequestHandleAdapter {

}
